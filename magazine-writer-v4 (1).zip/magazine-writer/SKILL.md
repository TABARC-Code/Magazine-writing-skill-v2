---
name: magazine-writer
author: TABARC-Code
version: 2.0
description: >
  Complete professional magazine article writing system. Use whenever a user wants to write, pitch, structure, draft,
  edit, or improve any magazine article, newspaper feature, Sunday supplement, or long-form journalism piece. Triggers
  on: "write me a magazine article", "help me pitch this idea", "what angle should I take", "how do I structure this
  feature", "long-form feature", "column", "profile piece", "news feature", "investigative piece", "travel feature",
  "how-to article", "interview feature", "opinion piece", "short story for a magazine", "roundup", "service
  journalism", "first-person narrative", or any request to produce or improve editorial writing for a publication.
  Also triggers for subject ideation, angle sharpening, query letters, lead writing, headline crafting, interviewing,
  research planning, revision, freelance contracts, or career development. Use even if the user has only a vague idea.
---

# Magazine Writer — Master Skill
**Author: TABARC-Code | Version 2.0**

A complete, source-validated system for producing professional-grade magazine and newspaper feature writing. Built from seven authoritative source texts:

- *Writer's Digest Handbook of Magazine Article Writing* (Ruberg, ed.)
- *Writing Feature Articles, 4th Ed.* (Hennessy)
- *Uncovering the Secrets of Magazine Writing* (Hamilton)
- *The Magazine Writer's Handbook, 2nd Ed.* (Peterson & Kesselman-Turkel)
- *How to Write Short Stories for Magazines* (King)
- *Writing to Inform and Engage* (Fink)

Covers the full workflow from initial idea through final copy, at the level expected by editors at serious consumer, trade, specialist, or literary publications and Sunday supplements.

---

## MANDATORY: Load modules before responding

Read the relevant module(s) FULLY before producing any output. Modules are not optional summaries — they contain the operative guidance.

---

## Module Map

| Task | Primary Module(s) | Also Read |
|------|-------------------|-----------|
| Finding, sharpening, or evaluating a subject/angle | `references/01_subject_and_angle.md` | — |
| Structuring the article (any type) | `references/02_article_structure.md` | `references/01_subject_and_angle.md` |
| Writing any lead or ending | `subskills/leads-and-endings/leads-and-endings.md` | `references/02_article_structure.md` |
| Prose, voice, sentences, rhythm, transitions | `references/03_prose_and_voice.md` | `references/05_publication_standards.md` |
| Full article draft | `references/01`, `02`, `03`, `subskills/article-type-master/article-type-master.md` | `references/05_publication_standards.md` |
| Pitching: query letters, synopses | `references/04_pitch_and_query.md` | `references/01_subject_and_angle.md` |
| Publication matching, tone, register | `references/05_publication_standards.md` | `references/03_prose_and_voice.md` |
| Research planning, interviewing, source-finding | `subskills/research-and-interviewing/research-and-interviewing.md` | — |
| Specific article type (profile, how-to, narrative, etc.) | `subskills/article-type-master/article-type-master.md` | `references/02_article_structure.md` |
| Editing/revising an existing piece | `subskills/revision-and-self-editing/revision-and-self-editing.md` | `references/03_prose_and_voice.md` |
| Short fiction for magazines | `subskills/short-fiction/short-fiction.md` | `references/05_publication_standards.md` |
| Continuous improvement, writer development, tracking progress | `references/06_kaizen_improvement.md` | — |
| Contracts, kill fees, rights, rates, career business | `references/07_freelance_business.md` | — |
| Named story structures (Kebab, Accordion, Five-Box, Diamond, etc.) | `references/08_story_structure_models.md` | `references/02_article_structure.md` |
| Specialisation, personal brand, editor relationships, resilience, writer's block | `references/09_writer_development.md` | `references/06_kaizen_improvement.md` |

---

## Core Principles (Always Apply)

**1. The angle is not the subject.**
"Climate change" is a subject. "Why your local council is sitting on a £4m green energy grant it cannot spend" is an angle. Magazine writing always needs the latter.

**2. The reader comes before the writer.**
Every sentence should answer an implicit question the reader is asking. If a paragraph doesn't serve the reader, cut it.

**3. Earn the opening; land the ending.**
The lead must hook, orient, and promise. The ending must pay off that promise.

**4. One idea per section. One section per idea.**
Magazine articles are modular. If a section is doing two things, split it.

**5. Specificity beats generality.**
Names, numbers, places, dates. "Sarah Mistry, who has taught Year 6 at Highgate Primary for eleven years" is always stronger than "a teacher in Birmingham."

**6. Show the seam between reporting and argument.**
Be transparent about what is fact, what is interpretation, and what is the source's view.

**7. Match the register to the publication.**
Voice, sentence length, vocabulary, tone, and structural formality all shift with the market. Never write in a vacuum.

**8. Cut the last 10%.**
First drafts are almost always 10–15% too long. The reader's needs survive the cut. The writer's don't.

**9. Maintain your point of view.**
Every strong feature has a single governing point of view. If material is creeping in that dilutes the angle, re-examine it.

**10. Fiction technique serves nonfiction.**
Scene-setting, dialogue, characterisation, tension, pacing — these are not decorative. They are the tools that make readers finish the piece.

**11. Kaizen — always improve, always iterate.**
Name one specific weakness before every draft. Fix it. Document what works. Treat rejection as data. The writer who improves 1% per piece, consistently, will be unrecognisable in a year. See Module 06 for the full improvement loop.

---

## Quick Reference: Common Magazine Writing Failures

| Failure | Symptom | Fix |
|--------|---------|-----|
| Subject without angle | "This is about X" | Find the specific claim or tension |
| Delayed lead | Real opening buried in paragraph 3 | Move it to line 1 |
| Missing nut graf | Reader doesn't know why they're reading | Add explicit "here's why this matters" after the hook |
| Quote overload | Article is 60%+ quotation | Paraphrase context; quote only the irreplaceable |
| Vague transitions | Sections feel disconnected | Signpost sentences at end/start of sections |
| Flat ending | Piece stops, doesn't land | Return to opening image/character or make a final claim |
| Wrong register | Sounds like a blog or academic essay | Read target publication; match sentence length and vocabulary |
| Passive voice drift | "It was decided that..." | Rewrite with agent: who decided? |
| Anecdote without payoff | Scene that goes nowhere | Connect every anecdote to the central argument |
| Once-upon-a-time narrative | Chronological from the beginning | Jump in at the crisis point; backtrack after |
| Formula writing | Dull predictability | Find the genuine tension; let it shape the structure |
| Unstated assumptions (how-to) | Reader confused mid-step | Walk through physically; state every prerequisite |
| "Fuzz" causation | Events presented as linked without proof | State chronological relationship honestly; don't imply causation |

---

## How to Use This Skill

1. Identify the task type and load the relevant module(s) from the map above.
2. If the user has a subject idea, start with Module 01 before drafting anything.
3. If drafting a full article, work through 01 → 02 → Article Type subskill → 03 in sequence.
4. If editing an existing piece, load the Revision subskill and Module 03.
5. If pitching, work through 01 and 04.
6. Apply the Core Principles to every output.
7. Always ask for or infer the target publication before finalising voice and register.
8. Never produce generic "magazine-style" writing. Specificity of publication is a quality gate.
9. For short fiction commissions, load the Short Fiction subskill — completely different workflow from feature journalism.
10. **Kaizen**: On every piece, name one improvement target before starting. After filing, document what worked and what didn't. Apply Module 06 systematically to develop across projects.

---

## Module Summaries

### Module 01 — Subject and Angle → `references/01_subject_and_angle.md`
Finding subjects, developing angles, stress-testing ideas, matching subject to publication. The full angle-development process and diagnostic questions.

### Module 02 — Article Structure → `references/02_article_structure.md`
The editorial hierarchy, lead types, nut graf, body sequencing, subheads, endings. Templates for all major feature types. Structural diagnostic questions.

### Module 03 — Prose and Voice → `references/03_prose_and_voice.md`
Register, sentence craft, active/passive, verb strength, transitions, quote handling, scene-setting, tone control, rhythm, readability. Tabloid technique toolkit. Prose failure catalogue.

### Module 04 — Pitch and Query → `references/04_pitch_and_query.md`
Query letter anatomy, templates, annotated examples, publication matching, following up, rejection handling, simultaneous submissions.

### Module 05 — Publication Standards → `references/05_publication_standards.md`
Publication DNA, calibration by type (broadsheet, consumer, trade, literary, specialist), house style basics, high-spec quality checklist.

### Module 06 — Kaizen: Continuous Improvement → `references/06_kaizen_improvement.md`
The Kaizen philosophy applied to writing craft. The four pillars (continuous improvement, error-proofing, standardised work, just-in-time) as writing practice. The improvement loop for every piece. Measuring development. Treating rejection as data. The personal standards document. Load when helping a writer develop their practice — not just their current piece.

### Subskill: Research and Interviewing → `subskills/research-and-interviewing/research-and-interviewing.md`
Tackling any topic, finding and evaluating sources, interview strategy, conducting and handling difficult interviews, organising research, e-interviewing, fact-checking protocol.

### Subskill: Article Type Master → `subskills/article-type-master/article-type-master.md`
Deep operational guidance for: personality profile, roundup, how-to/service, narrative, alarmer-exposé, personal experience/first-person, survey, opinion/column, travel, interview feature, art-of-living, children's, shorts/sidebars, templated writing.

### Subskill: Leads and Endings → `subskills/leads-and-endings/leads-and-endings.md`
Complete lead taxonomy with examples and construction guidance. Full endings toolkit. The bookend technique. Anecdote placement. Tabloid lead techniques applicable to all writing. Opening and closing failure catalogue.

### Subskill: Revision and Self-Editing → `subskills/revision-and-self-editing/revision-and-self-editing.md`
Three-level revision workflow (macro/mid/micro). Self-editing checklist. Common errors and fixes. Reading-aloud protocol. The final 10% cut. Rewriting vs editing.

### Subskill: Short Fiction for Magazines → `subskills/short-fiction/short-fiction.md`
Complete system for writing and placing short stories in consumer magazines. Market identification, story structure, characterisation, the twist ending, first lines, pacing, dialogue, submission strategy. Distinct from feature journalism — load separately.

### Module 07 — The Freelance Business → `references/07_freelance_business.md`
Rights and copyright (FSR, FNASR, all-rights, work-for-hire). Contract anatomy: kill fees, payment terms, indemnity clauses, expenses. Rates and negotiation. Building clips. Specialisation. Editor relationships. Diversifying income. Media law basics (libel, privacy, recording). Record-keeping for legal protection.

### Module 08 — Story Structure Models → `references/08_story_structure_models.md`
The seven named structural models used by professional journalists: Inverted Pyramid, Kebab/Circle, Accordion, Hourglass, Rick Bragg Five-Box, Diamond, Braided Narrative. When to use each. The Post-it storyboard method (Line Vaaben / Poynter). Structural diagnostic questions. Decision guide: which structure for which story type.

### Module 09 — Writer Development → `references/09_writer_development.md`
Specialisation strategy: identifying, building, and defending a beat. Personal brand: website, clips, professional presence. Editor relationships: becoming a regular, handling editorial changes, managing difficult relationships. Resilience: imposter syndrome, writer's block (seven causes with specific fixes), sustaining long-term practice. The Kaizen commitment in writer development.

---

## How the modules talk to each other

Every module ends with a **→ Where this module leads** section that tells Claude which modules to load next based on what the writer needs. The skill is one system, not fourteen isolated files.

The core workflow connections:

```
IDEA
  └─► 01_subject_and_angle
            │
            ├─► 05_publication_standards  (does this angle fit this market?)
            │
            └─► 04_pitch_and_query  ──────► 07_freelance_business
                                                    (commission → contract)
STRUCTURE
  └─► 02_article_structure
            │
            ├─► 08_story_structure_models  (named structural models)
            │
            ├─► leads-and-endings  (opening and closing in depth)
            │
            └─► article-type-master  (type-specific structural logic)

REPORTING
  └─► research-and-interviewing
            │
            └─► back to 01_subject_and_angle  (research reshapes angle)

DRAFTING
  └─► 03_prose_and_voice
            │
            └─► 05_publication_standards  (register calibration)

REVISION
  └─► revision-and-self-editing
            │
            ├─► 03_prose_and_voice  (micro pass reference)
            │
            └─► leads-and-endings  (lead and ending quality tests)

CAREER
  └─► 09_writer_development
            │
            ├─► 06_kaizen_improvement  (improvement loop)
            │
            └─► 07_freelance_business  (contracts and rates)
```

Every module's outbound links are specific and contextual — not "load everything" but "load this next, for this reason."
