# Subskill: Research and Interviewing
**Author: TABARC-Code | Version 2.0**
*Source-validated from: Ruberg (Writer's Digest Handbook ch5–6), Hennessy (Writing Feature Articles ch7–9), Hamilton (Uncovering the Secrets ch3–4), Fink (Writing to Inform and Engage)*

Research and interviewing are not preparatory steps before the writing begins. They *are* the writing, at its foundation. Weak research produces weak articles. Strong interviews produce the quotes, scenes, and anecdotes that no amount of prose skill can manufacture.

---

## PART ONE: RESEARCH

### The research mindset

Before you open a browser or make a call, define what you need:

1. What is the specific claim or argument this article is making?
2. What evidence would prove it, challenge it, or complicate it?
3. Who are the people affected, responsible, or expert?
4. What has already been written? What ground will you be covering for the first time?

Research that doesn't map to these four questions is unfocused accumulation. Focused accumulation.

---

### Tackling any topic

**Step 1: Background reading**
Read broadly before you read deeply. Get the overview before the detail. This prevents you from asking experts questions that basic research would answer — a waste of their time and a credibility cost to you.

Sources for background:
- Reference works, encyclopaedias, textbooks
- Quality journalism from the past 2–3 years (note: journalism contains errors — cross-check)
- Academic papers (abstract and conclusion; you don't always need the full paper)
- Institutional reports and white papers
- Parliamentary/Congressional records, court filings, company accounts (primary sources)

**Step 2: Finding experts**
Leaders in a field are better than generalists. A family doctor can discuss hypothermia in theory; a specialist who has treated fifty cases can discuss it in fact.

How to find experts:
- Professional and trade associations (they exist in every field)
- University press offices — they want coverage for their academics
- Think tanks and NGOs (note their funding and agenda when attributing)
- Court and corporate records — people named in proceedings
- Previous articles on the subject — trace their sources
- Ask one expert who else you should speak to; experts know each other

**Step 3: Evaluating sources**
Not all sources are equal. Ask:
- Does this person have first-hand knowledge or only second-hand opinion?
- Do they have an interest in the narrative they're advancing?
- Can what they say be corroborated?
- When was the last time they directly engaged with this subject?

Prefer a recording label's website over a fan site; prefer a specialist who treated the condition over a generalist who read about it.

**Step 4: Primary sources**
Wherever possible, go to the original. Statistics cited in journalism should be traced back to the study or dataset. Claims about what an organisation did should be checked against their documents, not third-party accounts. Court judgments, annual reports, internal memos (if accessible), and official records are all primary sources.

---

### Organising research

A system that works consistently is worth more than a system that is theoretically better but unreliable.

**Paper method:**
- New sheet for each source
- Full bibliographic details at the top
- Page number beside every note and quote
- Quotation marks around any verbatim string, however short
- Your own comments identified by initials in the margin

**Digital method:**
- New document or note per source
- Source details in the header
- Page numbers and quotation marks maintained
- Copy-paste from electronic sources preserves accuracy — but also makes it dangerously easy to reproduce without attribution
- Use word processor comments to flag source notes separately from quotes

**The cardinal rules:**
1. Quotation marks around any verbatim string, always — even three words. This prevents accidental plagiarism at the drafting stage.
2. Source and page number beside every item, every time.
3. Never combine quoted material, your paraphrase, and your own comments in the same paragraph of notes.

**Organising for writing:**
Once research is assembled, sort notes into thematic sections with headings. Assign source references to each heading. Allocate half a page per section and slot in the most significant material. This is not outlining for its own sake — it reveals what you have, what you're missing, and what the dominant structure wants to be.

---

### Making research go the distance

- Be a pack rat during research: business cards, brochures, maps, menus, annual reports, clippings, photographs. The paper trail supports fact-checking and may contain the detail that transforms a flat passage.
- Listen to your gut: when something feels wrong — when there's a nagging sensation — call the source again or recheck the reference. That sensation is usually correct.
- Research until you know more than you need. The security of over-preparation produces better writing and reduces errors.

---

### Fact-checking protocol

Before filing, check every factual claim in the piece:

- Names spelled correctly (a misspelled name can implicate the wrong person)
- Job titles, organisations, dates, figures — each verified against the original source
- Quotes checked against your notes or recording
- Any claim attributing an action to a specific person — does your evidence support the attribution?
- Statistical claims traced to their primary source

Errors in small details destroy reader confidence in the larger argument. Errors in attributing actions to named individuals can constitute libel.

---

## PART TWO: INTERVIEWING

### The strategic framework

An interview is a structured conversation with a purpose. That purpose is:
1. To obtain information you cannot get elsewhere
2. To get quotes that serve the piece (see Module 03 for the three-function test)
3. To observe the subject in a way that generates scene material and characterisation

The interview strategy should be planned, but flexible enough to follow where the subject leads.

---

### Before the interview

**Preparation:**
- Research the subject thoroughly before the conversation. Do not ask questions that published records already answer — it wastes time and signals unpreparedness.
- Write out your questions in advance. You may not ask all of them. You will ask others that weren't on the list. But the list is your structural spine.
- Know what you need by the end: what are the three to five things this interview must give you?
- Know the context: when did this person last speak publicly on this subject? What have they said before?

**Scheduling:**
- Arrange face-to-face when possible. Telephone is second choice. E-mail is third (for most purposes — see the roundup article exception below).
- Face-to-face produces better material: body language, observation, spontaneous exchanges, the detail of the environment.
- Allow more time than you need. Sources relax after the scheduled interview time ends — that is often when the most useful things are said.

---

### Conducting the interview

**Opening:**
- Start with simple, non-threatening questions to establish rapport
- Explain the article's purpose and publication (but not so much that the source tailors everything to what they think you want)
- Confirm whether you're recording (required in some jurisdictions)

**Core technique:**
- Ask open-ended questions: "Tell me what happened when..." / "Describe what you saw..." / "What did you do next?"
- Listen for hints of an anecdote lurking below the surface — then excavate: "Can you walk me through that moment?"
- Use silence. People fill silences. What they say to fill them is often more revealing than their prepared answers.
- Follow the thread. The prepared question list is the backbone; the subject's unexpected disclosures are the flesh.
- If a source says something surprising, ask them to say it again, or to expand. Don't rush past revelations.

**The "sensory data" imperative:**
Face-to-face interviews allow you to gather descriptive passages that phone interviews cannot supply. During the interview, observe:
- The subject's environment (what does it tell you?)
- Their physical presence, manner, habits
- Moments of hesitation, animation, discomfort
- What they do with their hands, where they look

This observation becomes the scene material that lifts a profile from competent to vivid.

**Getting the anecdote:**
The anecdote does not spontaneously appear. You mine it. When a source mentions an incident, follow up: "Can you tell me the full story of that?" / "What exactly did you say when that happened?" / "Who else was there?"

---

### Handling difficult interviews

**The evasive source:**
- Note what they refuse to answer — sometimes refusal is the story
- Return to unanswered questions from a different angle later in the interview
- Don't abandon a line of questioning after one deflection; ask it three ways

**The over-prepared source:**
- Has been media-trained and stays on message
- Push beyond the talking points with specific, concrete questions about specific moments
- "I understand the policy position — what I'm interested in is what happened on the day of the decision."

**The hostile source:**
- Do not become defensive; remain professionally curious
- Their hostility may indicate you're close to something important
- Maintain composure; aggressive interviews produce defensive answers

**The very forthcoming source:**
- Be alert to what they want from the interview
- What are they steering you toward? What are they steering you away from?

---

### E-mail and digital interviews

**Advantages:**
- Transcript-accurate quotes; no dispute about what was said
- The source has time to think; answers can be more considered
- Efficient for roundup articles where you need uniform answers from multiple sources

**Disadvantages:**
- No spontaneous exchange; no ability to follow threads in real time
- Sources may over-prepare and give polished, bloodless answers
- Body language and environmental observation impossible

**The roundup exception:**
For roundup articles (multiple sources answering the same questions), e-mail is actually preferable. Send the same set of questions to five or six sources. Build a comparison grid from the responses. Extract quotes as needed. This gives you structural control over the piece that a series of phone conversations cannot.

**When using e-mail quotes:**
Attribute them as such: "in an email interview" or "by email." Don't present e-mail responses as face-to-face statements.

---

### After the interview

**Immediately after:**
- Write up your notes and observations before memory degrades
- Flag the three best quotes and the most promising anecdote
- Note what you still need: what questions weren't answered? What claims need corroborating?

**Fact-checking quotes:**
- Purists: you cannot change a direct quote. Realists: minor grammar corrections that don't change meaning are acceptable. Hard line: never change meaning. If meaning-change is required, make it indirect.
- If allowing sources to review their quotes in advance (a debated practice): they may correct errors only — they may not rewrite meaning.

**Keeping records:**
- Retain recordings and notes
- If a source denies having said something, your record is your protection
- Tape-recording telephone conversations is legal in some jurisdictions and not in others — check before recording

---

## PART THREE: ORGANISING FOR WRITING

### From research to structure

With notes organised thematically:

1. Read through all material several times until familiar
2. Go for a walk; let a clear theme settle
3. Select what you need; put the rest aside (but don't delete — you may need it)
4. Divide notes into sections with headings: 1, 2, 3, 4...
5. Assign source materials (A, B, C...) to sections
6. Slot most significant material under each heading
7. Note links between sections in the margins

This is not the article's final structure. It is the scaffold that lets you see what you have and what is missing before you draft.

### The research gap check

Before drafting, ask:
- Is the central claim evidenced by at least two independent sources?
- Do I have at least one concrete anecdote that illustrates the central point?
- Do I have at least one human subject (not just institutional voices)?
- Are there significant objections to my argument that I haven't addressed?
- Have I traced every statistic to its primary source?

A "no" on any of these is a reporting gap, not a writing problem.

---

## → Where this subskill leads

**Research either confirms or reshapes the angle:**
Return to `references/01_subject_and_angle.md` after the first significant research phase — what you found may sharpen, redirect, or overturn the original angle. This is expected. Stress-test the angle against what the reporting actually produced.

**Research reveals which article type best serves the material:**
Load `subskills/article-type-master/article-type-master.md` — the strongest material you've gathered (an anecdote, a document, a person, a dataset) often indicates the right article type. If the best thing you found is a person, it's probably a profile or narrative. If it's a document, it's probably an investigation.

**For expenses and source agreements:**
Load `references/07_freelance_business.md` — if research has involved significant expense, or if a source is providing exclusive access, document the arrangements. Expenses must be agreed in advance; exclusive access sometimes warrants acknowledgement in contract terms.

**Once reporting is complete, build the structure:**
Load `references/08_story_structure_models.md` + `references/02_article_structure.md` — the Post-it storyboard method works best when all the reporting material is in hand. Organise the notes, then choose the structure.
