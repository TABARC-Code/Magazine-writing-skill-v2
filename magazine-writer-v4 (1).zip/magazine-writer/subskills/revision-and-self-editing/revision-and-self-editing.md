# Subskill: Revision and Self-Editing
**Author: TABARC-Code | Version 2.0**
*Source-validated from: Ruberg (Writer's Digest Handbook ch8), Hennessy (Writing Feature Articles ch12), Fink (Writing to Inform and Engage)*

The first draft is not the article. The revision is where the article is made. Professional magazine writers expect to revise; the ones who produce the best work revise the most thoroughly. This subskill provides the complete revision workflow, macro to micro.

---

## THE REVISION MINDSET

First drafts serve the writer. Revisions serve the reader. The shift from first to second pass is the shift from "getting it down" to "making it work."

Put the draft aside for at least an hour — ideally a day or two — before beginning revision. Distance creates objectivity. The inability to see the article fresh is the greatest obstacle to effective self-editing.

**Read the draft as an editor, not as a writer.** Ask: does this work for the reader? Not: does this represent my intention?

Read it more than once, concentrating on a different level each time.

---

## THREE LEVELS OF REVISION

### Level 1 — Macro (Structure and Argument)

This is the first pass. Do not edit sentences before you know the structure works. Editing prose in a piece that has structural problems is wasted effort.

**Questions:**

1. Is the overall purpose/theme/idea clear? Why did you write this? What did you hope to achieve? Was it effectively communicated?
2. Does the lead work as a hook, an orientation, and a promise?
3. Is the nut graf present, explicit, and early enough?
4. Does each body section do one clear job?
5. Is there a section that could be cut without the piece losing anything essential? (If yes, cut it.)
6. Does the ending pay off the opening?
7. Does the piece have a governing point of view sustained throughout? Or does it drift?
8. Is the content adequate for the purpose? Is it significant enough? Is there a gap that should have been filled with more reporting?

**Structural failures to fix at this level:**
- The real opening is buried in paragraph three — move it
- The nut graf is absent — add it
- Two sections are doing the same job — merge them
- A section is doing a job that belongs in a different place — move it
- The ending is a summary, not a landing — rewrite it

---

### Level 2 — Mid (Sections, Pacing, Transitions)

Once the structure is sound, check the internal logic of each section and the connections between them.

**Questions:**

1. Does each section make a clear point?
2. Does the pacing vary — is the body slower and more evidential where it needs to be, and faster as it builds to the end?
3. Are the transitions between sections invisible? (The reader should not notice moving from one section to the next.)
4. Does each section begin with something that pulls the reader into it?
5. Are quotes placed where they do the most work — or where they happened to fall during drafting?
6. Is the evidence proportionate to the claims?
7. Are there anecdotes that don't connect to the central argument? (Cut them, however good they are.)

**Transition audit:**
Read the last sentence of each section and the first sentence of the next. Does the connection feel natural? If there's a jolt, fix the transition — but also ask whether the section order is right.

---

### Level 3 — Micro (Sentence, Word, Rhythm)

This is the final pass. Read aloud. The ear catches what the eye misses.

**Questions:**

1. Is the register consistent throughout, and appropriate for the publication?
2. Are there sentences over 45 words that are doing genuine work — or just complicated?
3. Are the verbs strong? (Replace verb + noun constructions with single strong verbs.)
4. Are the nouns specific? (Replace generic nouns with specific ones where possible.)
5. Are there adjective clusters that could be reduced to one precise adjective?
6. Are there clichés in the first three paragraphs?
7. Is the active voice dominant where it should be?
8. Does every quote earn its place? (Apply the three-function test from Module 03.)
9. Are there "fuzz" passages — implied causations without evidence?
10. Are there words over four syllables that could be simpler without losing meaning?

**Reading aloud protocol:**
Read the entire piece aloud at normal speaking pace. Mark:
- Sentences that lose the thread (too long, too tangled)
- Rhythms that repeat three times in sequence (sentence patterns becoming monotonous)
- Clunky transitions that interrupt the reader's momentum
- Words that don't earn their syllables

Fix everything you marked. Read aloud again.

---

## THE FINAL 10% CUT

Almost all first drafts are 10–15% too long. The final revision task is identifying and cutting that excess.

**Method:**
1. Establish the target word count (from the commission or publication requirement)
2. Calculate how much must come out
3. Identify candidates in this order:
   - Redundant phrases ("the fact that," "it is worth noting that," "in order to")
   - Adjectives that don't add information
   - Background information the reader doesn't need to understand the argument
   - Anecdotes or examples that duplicate a point already made by another
   - Transitional sentences that state what the structure already shows

**The rule:**
Every cut must leave the meaning intact or improve clarity. If a cut changes meaning, restore the words.

**The test:**
Would a reader notice what was cut? If not, the cut is correct.

---

## SELF-EDITING CHECKLIST

Run this checklist on every piece before filing:

### Structure
- [ ] Lead hooks, orients, and promises — without summarising
- [ ] Nut graf is explicit, early, and answers: what is this, why does it matter, why now?
- [ ] Each section does one job
- [ ] No section could be cut without loss
- [ ] Ending pays off the opening without summarising it

### Content
- [ ] Every claim is attributed or evidenced
- [ ] Every quote serves voice, authority, or drama (Module 03 three-function test)
- [ ] Every anecdote connects to the central argument
- [ ] Every statistic traces to a named primary source
- [ ] The central claim is evidenced by at least two independent sources

### Prose
- [ ] No cliché in the first three paragraphs
- [ ] No sentence over 45 words without justification
- [ ] Active voice dominant
- [ ] Verbs are strong (no "gave consideration to," "made a decision")
- [ ] Nouns are specific
- [ ] No adjective stacking
- [ ] Register matches the target publication throughout

### Accuracy
- [ ] All names correctly spelled
- [ ] All job titles, organisations, and dates verified
- [ ] All quotes checked against notes or recording
- [ ] Any claim attributing an action to a named person — evidenced?

### Length
- [ ] Piece is at or within 5% of commissioned word count
- [ ] The final 10% has been reviewed for cuts

---

## COMMON REVISION ERRORS

### Editing sentences before fixing structure
The most expensive revision error. Do the macro pass first. Every sentence you polish in a section that will be cut or moved is wasted work.

### Editing what you intended to say rather than what you said
The draft on screen is not the draft in your head. Read what is there, not what you meant to put there. Reading aloud forces this confrontation.

### Protecting your favourite passages
If a passage is beautifully written but doesn't serve the piece, it must go. The test is not "is this good writing?" but "does this serve the reader at this moment?"

### Stopping after one pass
One pass is insufficient for professional work. The minimum for a serious piece is three passes at three different levels. Writers who submit after one pass are submitting first drafts.

### Editing under time pressure
Editing under deadline pressure produces the same errors as writing under deadline pressure. Build revision time into your schedule. If you don't have revision time, you don't have time to file — yet.

---

## REWRITING (SUBSTANTIVE REVISION)

Sometimes revision reveals that a section — or the whole piece — needs to be rewritten rather than edited. Signs:

- The structure makes no sense despite attempts to fix transitions
- The nut graf cannot be found because the central argument isn't clear
- The register is inconsistent throughout
- The evidence doesn't support the central claim

In these cases: step back to the structural level. Re-examine the angle (Module 01). Revisit the structure (Module 02). Rewrite with the correct structure in place before returning to prose-level editing.

**Rewriting is not failure.** It is the discovery that the first draft was a thinking draft, not a writing draft. Many of the best pieces in journalism were rewritten substantially. The draft is not sacred.

---

## REVISION AFTER EDITOR FEEDBACK

When an editor returns a piece with revision requests:

1. Read the feedback in full before acting on any part of it
2. Identify whether the requests are structural (angle, structure, content gaps) or cosmetic (style, cuts)
3. Structural requests: re-examine the piece at the macro level before editing
4. Cosmetic requests: work through systematically
5. If a request seems to misunderstand the piece's intent, query it — but be open to the possibility that the misunderstanding is in the draft, not the editor

Editors are not the enemy of the piece. They are the first reader. When an editor says something doesn't work, it is almost always because it doesn't work — even if not for the reason the editor names.

---

## → Where this subskill leads

**For prose-level revision (Level 3 — micro pass):**
Load `references/03_prose_and_voice.md` — the prose failure catalogue, verb strength table, and four style modes are the reference material for the micro revision pass. Keep it open alongside this subskill.

**For structural revision that keeps finding problems (Level 1 — macro pass):**
Return to `references/01_subject_and_angle.md` — structural problems that persist through multiple revision passes are almost always angle problems. If the structure won't resolve, the angle may not be clear enough to build a structure around.

**For revision as part of the improvement loop:**
Load `references/06_kaizen_improvement.md` — each revision produces data: what problems did you find? How many passes did it take? What does this tell you about your current weakness? Feed this into the personal standards document.

**For lead and ending revision specifically:**
Load `subskills/leads-and-endings/leads-and-endings.md` — the lead and ending quality tests in this subskill (cover the body; does the opening/ending work alone?) are the most important checks in the macro revision pass.
