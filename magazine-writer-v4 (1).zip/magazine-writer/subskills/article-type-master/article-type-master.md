# Subskill: Article Type Master
**Author: TABARC-Code | Version 2.0**
*Source-validated from: Ruberg (Writer's Digest Handbook ch9), Hamilton (Uncovering ch5–6), Hennessy (Writing Feature Articles ch13–19), Fink (Writing to Inform and Engage)*

Each article type has its own structural logic, common failure modes, and reader contract. This subskill provides deep operational guidance for every major magazine form.

Load this alongside `references/02_article_structure.md` for the editorial hierarchy and structural templates. This module adds the type-specific detail that the general structure module cannot carry.

---

## THE PERSONALITY PROFILE

### What it is
A profile illuminates a person in a way that reveals something broader — about an industry, a moment in culture, a human condition, or an idea. A good profile is not a biography or a press release. It is an argument made through a person.

### Structure
1. **Scene-setting lead**: the subject in a revealing moment — not their greatest achievement, but a moment that shows who they are
2. **Nut graf**: why this person, why now — the hook into the public story
3. **Current project/achievement**: what they are doing that justifies the piece
4. **Background and formation**: how they got here; the decisions that made them
5. **Defining challenge or turning point**: what tested them and what it revealed
6. **How they work / what they believe**: voice, method, philosophy
7. **What's next**: forward motion
8. **Closing image or quote**: returns to the opening; the reader leaves with a specific impression

### The interview for a profile
Face-to-face is not optional — it is the point. Observation during the interview produces the scene material that makes profiles vivid. What does this person do with their hands? What makes them laugh? What makes them go still?

### Common failures
- The "admiring portrait" that lists achievements and contains no tension or revelation
- Profile that never answers "why does this person matter?"
- Chronological narrative from birth to present (boring — jump in at the turn)
- All quotes, no observation or scene
- The subject controls the narrative; the writer has no independent point of view

### The writer's point of view
The best profiles have a governing question: "What is the real story about this person?" The interviewer does not abandon it because the subject gives a charming answer.

---

## THE ROUNDUP ARTICLE

### What it is
A roundup collects multiple expert voices or case studies around a single theme or question. The writer provides the thesis; the experts provide evidence and texture. No single source dominates.

### Structure
1. Lead: the theme or question, made vivid through one concrete example
2. Nut graf: why this question matters and what the roundup will illuminate
3. Body: three to six expert perspectives, organised thematically — not one after another in Q&A format, but woven into an argument
4. Conclusion: the pattern that emerges, the writer's synthesis

### Interviewing for roundups
E-mail is unusually appropriate here. Send the same set of questions to all sources. Build a comparison grid. This gives you structural control and ensures every source addresses the same issues, allowing genuine comparison.

### Constructing a comparison grid
List sources across the top; questions down the left side. Paste answers into cells. Print it out. The grid reveals where sources agree (confirming pattern), where they disagree (the interesting tension), and where they give the quote that crystallises the argument.

### Common failures
- The "ping-pong" roundup: source says X, source says Y, source says Z — with no synthesis
- All agreement, no tension — becomes a consensus statement, not an article
- Sources from the same background or institution — lack of diversity
- Finding your thread too late — the connecting theme must be in the lead

### The thread
Every roundup needs a thread — the single finding or tension that gives it shape. "New York Chefs Take a Walk on the Wild Side" works because every expert confirms it, from different angles.

---

## THE HOW-TO / SERVICE ARTICLE

### What it is
Service journalism solves a problem the reader has or anticipates. It transfers expertise from writer (or the writer's sources) to reader. Clarity is its only standard.

### Structure
1. **Lead**: the problem this piece solves — make the reader feel the need before you offer the solution
2. **Why this matters**: stakes, context, what happens if the reader doesn't do this
3. **What you need / prerequisites**: everything the reader must have or know before starting
4. **Steps in sequence**: numbered or clearly sequential; each step complete before the next begins
5. **Common mistakes / complications**: what goes wrong and how to fix it
6. **The payoff**: what the reader will have when done

### The sequence imperative
Steps must be in the right order — and must appear in the right order. The "bomb expert on the radio" failure: giving critical information *after* the irreversible step has been taken. Walk through the process physically. Don't instruct the reader to do something while at a location before telling them they'll need bricks — unless you want them to carry bricks there.

### Unstated assumptions
The single most common how-to failure. Every expert forgets what a novice doesn't know. Walk through each step with fresh eyes. What are you assuming the reader already has, knows, or has done? State it explicitly.

### Write with authority
You are the expert. Use the imperative voice: "Grasp the stem and pull it out" — not "You should grasp the stem." Explain the *why* as well as the *how* where it's not obvious: "Shake the colander until all water is drained — if water remains, the sauce won't thicken."

### Service journalism beyond how-to
Service journalism includes: health advice, financial guidance, relationship advice, consumer information. All share the same reader contract: the reader leaves with something actionable. Everything in the piece must serve that contract. Anything that doesn't is cut.

### Common failures
- Steps out of order
- Unstated assumptions stranding the reader mid-process
- Not writing with authority — hedging when the reader needs confidence
- Forgetting the payoff — the reader finishes without knowing they've succeeded

---

## THE ALARMER / EXPOSÉ

### What it is
The alarmer reveals a problem, danger, injustice, or failure the reader needs to know about. The exposé assigns accountability — this happened, these people knew, this was not an accident. Both require the highest standard of evidence.

### Structure
1. **Opening scene or case study**: the human cost, made specific
2. **Nut graf**: what the problem is, why it matters, why now
3. **Scale**: how widespread is this? Is this one case or a pattern?
4. **Background**: how did this happen? Who is responsible?
5. **Evidence** (in sections): the documentation, data, source testimony that proves the claim
6. **The institutional response**: what do the responsible parties say? Did they know?
7. **Wider implications**: what must change?
8. **The human cost**: return to the opening case, now understood differently

### Evidence requirements
Every claim that assigns responsibility to a named person or institution must be documented. Primary sources preferred: internal memos, official records, court filings. Secondary sources (testimony from affected parties) require corroboration. Statistics must trace to their original study.

### Protecting yourself legally
- Libel: a false statement that damages a living person's reputation. You can accurately print what you were told and still commit libel if the information was wrong.
- Verify every factual claim independently. Double-check; triple-check.
- Retain all notes, recordings, and documents.
- If a source claims something happened and only one source supports it, it is an allegation — attribute it as such.
- Reach the subject of any negative claim for response before publication. Their response (or refusal to respond) is part of the record.

### Common failures
- Single-source claims presented as established fact
- Confusing correlation with causation
- The accusation buried so gently the reader doesn't register it
- The accusation not buried gently enough — claims that outrun the evidence
- No institutional response — creates legal exposure and appears one-sided

---

## THE NARRATIVE FEATURE

### What it is
A narrative feature tells a story: something happened, there were people, there were consequences. The best narrative nonfiction uses every technique of fiction — scene, dialogue, characterisation, tension, pacing — in service of factual events.

### Structure
Not chronological. Jump in at the crisis point or moment of maximum tension. Back-fill when the reader needs context. Return to the forward-moving narrative. End at the moment of resolution or the moment that reframes everything.

A typical narrative arc:
1. **Opening scene**: in medias res — the moment of highest tension or most revealing character
2. **Nut graf**: the stakes, the context, what this story is about beyond the events themselves
3. **Background**: the road that led here, told as the reader needs it rather than chronologically
4. **The unfolding**: events with their own internal logic; scenes and summary alternating
5. **Turning point**: the moment that changes everything
6. **Consequences and meaning**

### Saving surprises
The narrative structure's engine is suspense. Changes of direction, reversals, complications, and revelations should be distributed through the piece — not all disclosed in the nut graf. Hennessy on this: "Notice the way the surprises in the story are saved up to keep the suspense going, change the pace, provide changes in direction."

### Scene vs summary
Scenes are where the reader actually experiences the story. Summary moves the narrative forward efficiently. The ratio depends on what's happening: write scenes for moments of drama, decision, or revelation; use summary to cover ground between those moments.

### Common failures
- Chronological from the beginning (the "once upon a time" failure)
- Insufficient scene material — the writer didn't observe, only reported
- Pace that never varies — scenes of equal weight throughout
- Endings that trail off rather than resolve or reframe

---

## THE PERSONAL EXPERIENCE / FIRST-PERSON FEATURE

### What it is
The writer's own experience is the vehicle for a larger truth. The experience is real, specific, and evidenced; the larger truth is the reason the editor commissioned it.

### The danger
First-person writing mistakes the writer's experience for the reader's interest. The writer must earn every "I." The personal story is not the point — it is the vehicle.

### Structure
1. The experience itself: specific, honest, observed — not a parable
2. The moment that required a question or a change
3. The wider context the experience illuminates (the nut graf equivalent — "I am not alone in this")
4. Outward reporting: other people's experiences, expert voices, data — the piece must reach beyond the writer
5. Return to the writer's experience: resolution or new understanding

### The universal inside the specific
The test: can a reader who has not had this experience find themselves in it? The specific must contain the universal. "My divorce" is not a story. "What I learned about property law, custody, and the cost of assuming marriage is permanent" is a story that happens to use a divorce.

### Common failures
- The piece that never leaves the writer's head
- Insufficient outward reporting — the writer's experience as the only evidence
- Over-emoting — the writer instructs the reader how to feel rather than showing what happened
- The tidy resolution that dishonours the mess of the actual experience

---

## THE SURVEY ARTICLE

### What it is
A survey covers a field — "here is the state of X." It may be a trend piece, a "state of the art," or a "what's happening in this sector" piece. It does not argue a single claim; it maps a territory.

### Structure
1. Lead: the most striking or surprising development in the territory
2. Nut graf: why the territory matters now
3. Sectioned body: each major aspect of the territory as its own section
4. Synthesis: what the survey reveals — is there a pattern? A direction? A conclusion?

### Common failures
- A survey without a governing question becomes an unfocused list
- Mistaking comprehensiveness for quality — a survey must still have an argument
- All overview, no human detail

---

## THE OPINION COLUMN

### What it is
The writer makes a claim, argues it, acknowledges the opposition, and wins the reader to the position. The claim is the product; the evidence is its justification; the counterargument is its test.

### Structure
1. **Hook**: the specific thing prompting the column — not an abstract topic but a concrete provocation (a news event, a statistic, an experience)
2. **The claim**: stated plainly; the reader knows exactly what is being argued
3. **Evidence**: two or three strong examples or arguments; specific, not vague
4. **The counterargument**: name it, acknowledge its force, then rebut it; this is what separates a column from an op-ed pamphlet
5. **The conclusion**: restate the claim with greater force, using what the argument has built

### Voice
The column is a direct relationship between writer and reader. The writer's personality — opinions, wit, frustration, enthusiasm — is the product. Voice must be strong enough to carry an argument.

### Common failures
- The column that never states the claim (dances around it)
- Evidence that only confirms the writer's existing view
- No counterargument — the piece feels one-sided and intellectually weak
- The ending that re-summarises instead of landing harder

---

## THE TRAVEL FEATURE

### What it is
Travel writing uses a journey to explore a place, a culture, or an idea. The best travel writing is never "just" about a destination — it is about what the place means, what the writer discovers, what the encounter between writer and place reveals.

### The animating idea
Every strong travel piece has an animating idea — a question or tension the journey is exploring. "Rome is beautiful" is not an animating idea. "What it means to live in a city that refuses to forget its past" is.

### Structure
1. **Evocative scene-setting lead**: put the reader somewhere specific; sensory; moving
2. **The animating idea**: why this place, why now, what the piece is really investigating
3. **Journey and discovery**: scenes alternating with reflection; movement through the place
4. **Cultural and practical insight woven in**: not in a service-box but as part of the narrative
5. **Ending that returns to the animating idea**: the journey has answered, challenged, or complicated the opening question

### The trap
Travel writing becomes a list of what the writer ate, saw, and did. The itinerary is not the piece. What did the encounter reveal?

### Common failures
- The itinerary format — no governing idea, just chronological movement
- Clichéd description ("azure waters," "bustling markets")
- The writer as tourist rather than participant or observer
- No return to the animating idea — the ending is just the last stop

---

## THE INTERVIEW FEATURE

### What it is
An in-depth interview shaped into a feature. Not a Q&A transcript — a shaped, argued piece that uses the conversation as its primary material but brings the writer's intelligence to bear on it.

### Structure
1. **Scene**: where the interview takes place and what the subject's presence reveals
2. **Nut graf**: who they are and why now
3. **Thematic sections**: the conversation organised by theme, not by the order questions were asked
4. **Background woven in**: context inserted where the reader needs it
5. **A revealing moment or exchange**: the line that captures something essential
6. **Closing image or quote**

### The difference from Q&A
A Q&A is a transcript. An interview feature is a portrait. The writer selects, shapes, and interprets. The writer's intelligence is visible in what is included, what is cut, and how the material is ordered.

### Common failures
- Publishing the interview in the order it happened
- Using every quote rather than the best ones
- No governing idea — "here is what this person said" rather than "here is what this person reveals about X"

---

## CHILDREN'S MAGAZINE WRITING

### What it is
Writing for children's publications follows the same professional standards as adult writing, with additional requirements for age-appropriate content, reading level, and engagement.

### Key differences from adult writing
- Reading level must match the target age band precisely — too easy is condescending; too hard loses the reader
- Vocabulary: define specialist terms on first use; never assume knowledge the age group won't have
- Tone: enthusiastic, never patronising; curious, never didactic
- Examples must be from within the child's world of experience
- Length is typically shorter; paragraphs are shorter; sentences are shorter
- Active, present-tense language wherever possible

### Content
- Accuracy is non-negotiable — children remember what they read in magazines
- Complex issues (health, social problems) must be handled with particular care
- Avoid frightening information without context or coping frame

---

## SHORTS, SIDEBARS, AND QUIZZES

### Shorts (200–600 words)
Front-of-book items, news briefs, trend notes, quick profiles. The same standards apply as to longer features: specific angle, earned lead, paid-off ending. The difference is proportion. Everything is compressed.

**Shorts are not abandoned pieces.** They are complete in themselves. A 400-word short should have the same structural integrity as a 2,000-word feature — just smaller.

### Sidebars
The sidebar supplements a main feature with information that doesn't fit naturally into the narrative flow: resources, statistics, timeline, competing viewpoints, glossary, "what to do now" checklist.

Rules:
- The sidebar must be useful independently of the main article
- It should not contain material the main article also covers
- It should be complete and accurate in its own right

### Quizzes
Quizzes provide interactive value. They are most useful when:
- The questions test knowledge the article actually imparts
- Results are genuinely differentiated (not all roads lead to the same answer)
- The format matches the publication's tone

Poorly designed quizzes mislead readers; well-designed ones extend engagement.

---

## THE ART-OF-LIVING FEATURE

### What it is
A feature about how people live — relationships, habits, lifestyle choices, personal philosophy. Often tied to a cultural or social trend. The human subject illustrates a broader truth about how people are choosing to live.

### Requirements
- A compelling human subject or subjects (not a concept alone)
- Research that places the individual stories in context
- The larger meaning made explicit

### Common failures
- The "isn't this interesting" piece that doesn't have a claim
- Human subjects as illustration only, without genuine depth
- The piece that could have been written without speaking to anyone

---

## TEMPLATED WRITING

### What it is
Templating is the practice of writing a piece that works across multiple non-competing publications with different audiences, by adjusting the industry-specific examples and sources while keeping the generic framework.

### When it's appropriate
- Trade and professional publications that share a subject (different industries, same professional problem)
- Service journalism topics with universal relevance (how to find a lawyer, manage tax, hire well)

### The template structure
1. Generic lead, theme paragraphs, and ending — slightly adjusted for each publication
2. Generic expert voices (applicable to any industry)
3. Industry-specific examples, sources, and case histories — these change for each version
4. Language and references calibrated to each industry's vocabulary and concerns

### The critical requirement
Each version must feel as if it was written specifically for that publication's reader. "Familiarise yourself with the industry you're writing for" — the template is the scaffold, not the building. Mechanical substitution of industry names produces work that reads as mass-produced. Genuine industry-specific insight does not.

### Common failures
- Mechanical substitution of industry name without genuine customisation
- Generic experts only; no industry-specific voices
- Forgetting that the angle may need adjustment for different audiences

---

## → Where this subskill leads

**For the named structural model that fits this article type:**
Load `references/08_story_structure_models.md` — the decision guide maps article types to structural models. Profiles → Kebab or Five-Box. Investigations → Accordion. Opinion → Diamond. Use this to confirm the structural choice.

**For type-specific lead and ending approach:**
Load `subskills/leads-and-endings/leads-and-endings.md` — each article type has a characteristic opening and closing. Profiles open with scene-setting; alarmers open with the human cost; how-tos open with the problem.

**For research requirements specific to this article type:**
Load `subskills/research-and-interviewing/research-and-interviewing.md` — profiles need face-to-face interviews; roundups need the comparison grid; investigations need primary source documentation. Each type has its own research logic.

**For pitching this article type:**
Load `references/04_pitch_and_query.md` — name the article type explicitly in the pitch ("a 2,000-word narrative investigation" or "a 1,500-word profile"). Editors commission types, not just subjects.
