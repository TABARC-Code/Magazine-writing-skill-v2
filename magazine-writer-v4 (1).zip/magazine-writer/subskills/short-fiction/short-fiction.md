# Subskill: Short Fiction for Magazines
**Author: TABARC-Code | Version 2.0**
*Source-validated from: King (How to Write Short Stories for Magazines and Get Published)*

Short fiction for consumer magazines is a distinct discipline from literary fiction, journalism, and general creative writing. It has its own market requirements, structural conventions, and reader contracts. This subskill covers the complete workflow: idea to submission.

**Important**: Load this subskill independently from the feature-writing modules. The short fiction workflow is different in almost every respect. The only areas of overlap are market identification (Module 05) and the principle of specificity (Core Principle 5).

---

## THE MAGAZINE SHORT STORY: WHAT IT IS

A short story written for a consumer magazine (Woman's Weekly, People's Friend, Take a Break, and their international equivalents) is:

- Complete in itself: a single dramatic event, decision, or revelation
- Reader-friendly: accessible, engaging, emotionally satisfying
- Market-calibrated: written for a specific publication's specific readership
- Economical: every scene, character, and detail earns its place

It is NOT:
- A compressed novel
- A character sketch without plot
- Literary experimentation unless the market specifically invites it
- A vehicle for the writer's personal catharsis

---

## PART ONE: MARKET IDENTIFICATION

### Study the market before writing

The most common reason short fiction is rejected: it was written for the wrong magazine, or written without reading the magazine carefully.

**Before writing anything:**
1. Read at least three current issues of your target publication
2. Study the fiction section specifically: how long are the stories? What genres appear?
3. Identify the target reader: What is their demographic? What concerns, relationships, and experiences does the magazine reflect?
4. Request or download the magazine's writer's guidelines (most major publications provide them)

### What to look for in a target magazine

- **Length**: Most consumer magazine short stories run 800–2,500 words; some have specific slot requirements
- **Genre mix**: romance, women's fiction, twist tales, seasonal stories, humour — which are represented?
- **Tone**: cosy or gritty? Aspirational or grounded? Contemporary or historical?
- **Endings**: do the published stories end happily? Ambiguously? With a twist?
- **Protagonist demographics**: who are the main characters? What age, background, concerns?
- **Subject matter**: is there material the publication consistently avoids?

### Targeting specific readers

The consumer magazine short story reader is reading for pleasure, comfort, and emotional satisfaction. They want to be transported, moved, amused, or intrigued — and to arrive at the ending feeling the time was well spent.

Writing "for everyone" is writing for no one. The story for *Woman's Weekly* is not the story for *Viz* is not the story for *New Scientist*. Specificity of audience is the prerequisite.

---

## PART TWO: THE IDEA

### Sources of story ideas

**The best ideas often come when you're thinking about something else.** Don't force it. Observe, listen, read, and let the ideas find you. Productive sources:

- **Overheard conversations**: not to reproduce them, but as triggers — the two girls on the bus describing "him" (his eyes, his legs, his amazing presence) who turns out to be a horse. That's a story.
- **Personal experience**: what you are good at, what you have been through, what you have observed at close quarters. Writers who write what they know — not limiting themselves to autobiography, but drawing on genuine understanding — produce more authentic work.
- **Problem pages**: every letter to an agony aunt is the seed of a story. What if the innocent explanation turned out to be true? What if the obvious explanation turned out to be wrong?
- **Newspapers and magazines**: factual features trigger fictional possibilities. Not to copy — to spark.
- **Pictures and photographs**: ask what happened just before the image, and what is about to happen after it.
- **Other people's stories**: with permission, and fictionalised — one of the richest sources.
- **The mundane made strange**: a laundry basket, a bus queue, a supermarket checkout. The ordinary observed closely is full of story.

### From trigger to idea

Don't think too hard about an idea immediately. The best story ideas develop in the background — note the trigger, let it germinate, return to it. Force rarely produces the best work.

**Test questions for a story idea:**
- Is there a character here with a problem or a desire?
- Is there something at stake — something that will change if the character succeeds or fails?
- Is there a moment of decision or revelation?
- Is there a surprise available — something the reader doesn't expect?

---

## PART THREE: STORY STRUCTURE

### The single dramatic event

Most successful magazine short stories turn on a single dramatic event, decision, or revelation. Not a series of events, not a life story — one moment, one question, one change.

Ask: what is the ONE thing this story is about? If the answer requires more than one sentence, the story may be too complex for the form.

### Three-act compression

Even a 1,000-word story has a beginning, middle, and end:

1. **Situation**: who is this, where are they, what is their world?
2. **Disturbance**: something changes, or threatens to change, or must change
3. **Resolution**: the character acts, decides, or understands something — and the world is different

The disturbance is the engine. Without it, there is no story.

### The inciting incident

The story begins the moment the disturbance arrives — not before. Don't spend 300 words establishing the protagonist's background before the story starts. Begin with or near the inciting incident. Background can be fed in through dialogue, observation, or brief reflection as the story moves.

### Pacing

Short fiction cannot afford dead weight. Every scene must do at least two things simultaneously: advance the plot AND reveal character. Scenes that do only one — or neither — are cut.

---

## PART FOUR: THE TWIST ENDING

### What a twist is

A twist ending reveals that something the reader believed to be true is not true — or that something additional is true that completely changes the meaning of what came before. Done well, it is the single most satisfying element in magazine short fiction. Done badly, it is a cheat.

### Rules of the fair twist

1. **It must be foreshadowed**: the clues must be in the story. On rereading, the reader should see them. They should be placed so the reader didn't notice them on first read — but they must be there.
2. **It must be logical**: the twist must follow from the story's established facts. A twist that requires information withheld without reason, or that contradicts established character, is unfair.
3. **It must change meaning**: a twist that merely surprises is a gimmick. A twist that makes the reader understand everything that came before differently — that is the real thing.
4. **It must be earned**: the final revelation must feel satisfying, not arbitrary.

### Constructing a twist

Work backwards from the twist. If you know the revelation, you can plant the clues deliberately. On the first draft, you may not know the twist; on revision, you build back toward it.

The "horse" story above: plant the descriptions (legs, eyes, intensity) in language that signals romance — but is technically accurate for a horse. The misreading is the reader's; the honesty is the writer's. That is the fair twist.

### When not to use a twist

Not every magazine story requires a twist. Domestic fiction, character studies, and emotional resolutions can satisfy without revelation. Match the ending type to the publication and the story's register.

---

## PART FIVE: CHARACTERISATION

### The compact character

A short story has room for one fully developed character (the protagonist) and one or two supporting characters. More than this and the story becomes diffuse.

### Character creation

**Use pictures**: find an image that matches your protagonist's appearance. Physical specificity supports internal specificity.

**Use specialisation**: give your character a distinctive world. A doctor character brings medical knowledge that adds texture. A supermarket checkout worker brings a particular kind of social observation. What your character does shapes how they see.

**Let character drive plot**: the character's flaw, desire, or fear should cause the plot to happen. Characters who are merely affected by plot are passive; characters who create the situation by being who they are produce stories with inevitability.

### Revealing character

Show, don't tell — but in the specific way relevant to short fiction:

- What the character notices reveals who they are
- What they do under pressure reveals their true values
- What they say vs what they think creates irony and depth
- Small, specific actions reveal more than stated descriptions

---

## PART SIX: DIALOGUE

### The purposes of dialogue

In magazine short fiction, dialogue must do at least two things simultaneously:
- Reveal character (how this person speaks, what they value, what they're hiding)
- Advance the plot (what changes, what is at stake, what is discovered)

Dialogue that exists only for exposition ("As you know, Bob, we've been friends for twenty years...") is a craft failure.

### How people actually speak

Characters should sound different from each other. Vocabulary, rhythm, the things they avoid saying — all these distinguish voices. Read dialogue aloud. If every character sounds like the author, rewrite.

### Attribution

"Said" is almost always sufficient. Adverbial attributions ("she said tearfully," "he replied angrily") are usually a sign that the dialogue isn't doing the emotional work on its own. Fix the dialogue; don't patch it with attributions.

---

## PART SEVEN: FIRST LINES

### The first line's job

In magazine short fiction, the first line must:
1. Create immediate curiosity or engagement
2. Establish voice and tone
3. Begin the story — not prepare for it

The reader has already decided whether to read by the end of the first paragraph. There is no warming-up.

### Types of effective first lines

- **The intriguing situation**: "I've been hiding the letters for six weeks, and I'm running out of places."
- **The voice hook**: "My grandmother spent forty years lying about her age, and she was completely right to."
- **The unexpected perspective**: "The dog knew what was in the shed."
- **The immediate action**: "She left the envelope on the kitchen table and walked out."

### What doesn't work

- Atmospheric scene-setting that doesn't contain a story
- Starting with weather (unless weather is the point)
- Starting with waking up (one of the most common clichés in fiction submissions)
- Beginning with backstory instead of story

---

## PART EIGHT: REVISION AND SUBMISSION

### Self-editing the short story

After drafting:
1. Does the story begin at the right moment? (Usually: later than you started)
2. Is every scene doing at least two things?
3. Is the protagonist active — driving the plot — or merely reactive?
4. Is every character necessary? Could two be merged?
5. Does every line of dialogue reveal character AND advance plot?
6. Is the twist fairly planted? (Reread looking for clues — are they there but hidden?)
7. Does the ending feel earned?
8. Have you cut everything that isn't the story?

### Length calibration

Check the target publication's requirements before submitting. If the publication runs 1,500-word stories and you've written 3,000 words, you are not submitting to that publication — you are submitting something else and hoping they'll overlook it. They won't.

### Submission strategy

- **Never submit to a publication you haven't read**
- Read the guidelines; follow them exactly
- Tailor the story to the market; don't submit the same story unchanged to every magazine
- Multiple submissions (same story to multiple markets simultaneously) is accepted in short fiction — check each publication's policy
- After rejection: assess the feedback if any, then revise or resubmit elsewhere; one rejection proves nothing

---

## → Where this subskill leads

**For market calibration before submitting:**
Load `references/05_publication_standards.md` — consumer magazine short fiction has its own market-reading process, but the publication DNA section applies: read the target publication, count word lengths, note tone, identify what the editor consistently commissions.

**For revising the short story before submission:**
Load `subskills/revision-and-self-editing/revision-and-self-editing.md` — the three-level revision workflow applies to short fiction as directly as to features. The macro pass checks structure and whether the story starts in the right place; the micro pass checks first lines, dialogue attribution, and sentence rhythm.

**For the short fiction first line as a lead equivalent:**
Load `subskills/leads-and-endings/leads-and-endings.md` — the first line of a short story operates like a magazine lead: hook, orient, promise. The lead taxonomy (declarative, scene-setting, contrast) applies in short fiction terms.

**For the submission strategy as a pitching equivalent:**
Load `references/04_pitch_and_query.md` — short fiction submissions differ from article pitches (you submit a completed story, not a query), but the market research, targeting, and follow-up discipline are the same.
