# Subskill: Leads and Endings
**Author: TABARC-Code | Version 2.0**
*Source-validated from: Ruberg (Writer's Digest Handbook), Hennessy (Writing Feature Articles), Hamilton (Uncovering), Fink (Writing to Inform and Engage)*

The lead and the ending are the two most scrutinised parts of any magazine piece. Editors decide within the first paragraph. Readers decide whether the time was well spent in the last. This subskill covers both in full operational detail.

---

## PART ONE: LEADS

### What a lead must do

A good lead does three jobs simultaneously:

1. **Hook** — gives the reader a reason to continue into the second paragraph
2. **Orient** — establishes the world of the piece without fully explaining it
3. **Promise** — implies what is coming without giving it away prematurely

It does NOT need to summarise the article. The nut graf does that. The lead's job is to earn the nut graf's right to exist.

---

### Lead taxonomy

**1. The Anecdote Lead**
Opens with a specific scene, moment, or incident. The most common and most effective lead in feature journalism when the anecdote is genuinely compelling.

Requirements for an anecdote lead to work:
- The anecdote must be specific — named person, real place, dateable moment
- Something must happen — there must be action, tension, or surprise
- It must connect directly to the piece's central claim (not decoratively)
- It should contain dialogue, sensory detail, or both

*Example construction*: One evening in 1973, Bob Bitchin pulled his chopper up to a stoplight on the Sunset Strip. He made eye contact with a man in a fur coat behind the wheel of a Ferrari. When the light turned green, they raced. The driver turned out to be Evel Knievel — and their night of entanglement with the law later made it into a Rolling Stone article. (Adapted from Steve Wilson, *Folio:*)

**2. The Declarative Lead**
Opens with a bold, specific statement of fact or claim. Works for pieces where the insight itself is the hook.

Requirements:
- Must be specific, not vague ("The housing crisis is getting worse" is not a declarative lead — it is a platitude)
- Must surprise or challenge the reader's existing assumption
- The claim must be defensible and evidenced in the piece

**3. The Scene-Setting Lead**
Establishes place, atmosphere, or situation before introducing a person or argument. Used in travel, profile, and narrative features.

Requirements:
- Must include at least two sensory details
- Must move — no static descriptions of what things look like; show what is happening
- Must connect to the piece's animating idea within 2–3 paragraphs

**4. The Contrast Lead**
Opens with a juxtaposition — what was expected vs what happened; what was then vs what is now; what appears to be vs what is.

Requirements:
- The contrast must be real and striking, not manufactured
- Both sides of the contrast must appear in or near the opening paragraph

**5. The Question Lead**
Use sparingly. Only with a question the reader is already urgently asking. Avoid rhetorical questions that feel cheap ("Is the NHS broken?").

A question lead works when:
- The question is genuinely unanswered and important
- The piece's purpose is explicitly to answer it
- The question is phrased in a way that is surprising or provocative

**6. The "Best Shot" Lead (Tabloid Technique)**
Tell the whole story in the lead. Put your most shocking, surprising, or revelatory element first. Don't save it as a payoff — most readers will not wait.

*Example*: Kirk Douglas put a pistol in his mouth, determined to kill himself, and only an accident of fate prevented him from pulling the trigger. (*The Globe*, reviewing Douglas's autobiography)

This technique is appropriate for:
- News features
- Celebrity profiles  
- Exposés and alarmers
- Any piece where the central revelation is strong enough to be its own hook

**7. The Circular/Suspended Lead**
Opens in the middle of a scene or action, then cuts to the nut graf, with the resolution of the opening scene held back until the ending. Creates a structural frame the entire piece can hang on.

Best used in:
- Investigative features
- Profiles with a dramatic central event
- Narrative non-fiction

---

### The three-part intro structure (Hennessy)

For complex features of 1,500 words or more, the intro often has three distinct beats:

1. **Hook** — the arresting opening moment, image, or claim
2. **Bridge** — context that raises questions and draws the reader forward; background that makes the hook meaningful
3. **Text (Nub/Pivot)** — the explicit statement of what the piece is about; the transition into the body

These can be three sentences, three paragraphs, or three sections depending on length. They must work as a team.

*Example structure from Kampfner, New Statesman*:
- **Hook**: Conflicting quotes from Israeli and Palestinian diplomats, both expressing frustration at Europe
- **Bridge**: Questions — why does Europe appear so powerless? Four competing explanations posed
- **Text**: "The situation is demeaning." — statement of the piece's core claim, moving into the body

---

### Lead failures to avoid

- Starting with "In recent years..." (positioning statement, not a hook)
- Starting with a dictionary definition (the oldest cliché in student journalism)
- Starting with a quote (almost always; the writer, not the source, should earn the opening)
- Starting with the writer's arrival at a location ("As I drove up to the building...")
- Burying the real opening in paragraph three (most common failure)
- The "worthy but dull" opening — accurate, well-intentioned, and utterly flat
- Adjective-stacking in the opening sentence ("In a vibrant, bustling, unmistakably modern city...")
- The question that answers itself ("Is climate change real? Scientists say yes.")

---

### Anecdotes: placement and construction

Anecdotes are ministories. They bring generalities to life. They are not decoration — they are tools.

**Where anecdotes can go:**
- The lead (most common for profiles and trend stories)
- The ending (leaves a ministory in the reader's mind)
- The body (to illustrate and enliven a section)
- Split across lead and ending (open with the setup; close with the resolution)

**Constructing effective anecdotes:**
1. Write tightly — the anecdote is not the point; it serves the point
2. Use fiction techniques: plot, dialogue, characterisation, sharp words, description
3. Something must happen — there must be action or change
4. People who speak should sound like people, not policy documents
5. Choose one vivid word per detail; don't stack adjectives
6. Length in proportion to piece — a 350-word anecdote in a 1,000-word piece is out of balance

**Finding anecdotes:**
- Open-ended interview questions: "Tell me what happened when..." / "What did you do that day?"
- Face-to-face interviews (more productive than phone for anecdotal material)
- Documents — diaries, letters, court records, old interviews — are anecdote mines
- Your own observation during reporting visits

**Anecdote discipline:**
- Omit anecdotes that fail to bolster a relevant point, however entertaining
- Skip anecdotes that are repetitive or clash with the piece's tone
- Never use an anecdote you cannot verify

---

## PART TWO: ENDINGS

### What an ending must do

A good ending does at least one of three things:

1. **Closes the loop** — returns to an image, character, or question from the opening
2. **Lands the central claim** — crystallises what the piece argued or revealed
3. **Leaves the reader with something** — a thought, a feeling, a question worth carrying beyond the page

The appropriate ending style depends on publication type, audience, and the tone of the piece. A brief informational piece cannot sustain an extended anecdote close. A human-interest feature will feel cheated by a "just the facts" wrap-up.

---

### Ending types

**1. The Quote Ending**
A definitive quote that sums up the issue and adds pathos or insight. Not just any quote — the quote that makes the reader feel the whole piece has been building to this moment.

Requirements:
- The quote must feel earned, not tacked on
- It should add a dimension the writer's prose hasn't stated directly
- It should connect the subject to the reader: "this is not just about birds — it's about all of us"

**2. The Writer's Last Word**
The writer responds briefly to a closing quote, adding a layer of meaning. Limited to one or two sentences. Effective when the source's quote is interrogative or controversial and the writer can sharpen it.

**3. The Bookend (Full Circle)**
Revisits a word, phrase, image, or situation from the opening — often with a twist, development, or new meaning. Reminds the reader why they started reading and shows the journey the piece has made.

*Example from Lauren Mosko (concert preview)*: Opens with a joke about garage rock and garages; closes with the same joke twisted — "if you're not there by nine, don't expect to find a decent parking space." The callback signals authorial control and gives the reader the pleasure of recognition.

**4. The Suspended Resolution**
If you opened with a scene that was held in suspension (the circular lead), you now resolve it. What happened? The anecdote opened, held tension, and now closes.

**5. The Implication Ending**
Ends on the downstream consequence or the unanswered question the piece raises — not as a rhetorical dodge but as a genuine provocation. Used in investigations and analytical pieces.

**6. The Glimmer of Hope**
For problem-centred pieces: ends on a cautious positive note that acknowledges difficulty without false comfort. Avoids saccharine resolution.

*Example from Hennessy*: On the question of arming more police: "The policy would have to be cautiously implemented."

---

### Ending failures to avoid

- Summarising what you just said ("In conclusion, we have seen that...")
- Ending on someone else's quote when the writer should make the final move
- The "and so we see that..." wrap-up
- Trailing off without resolution
- Ending on a rhetorical question when a statement would be stronger
- Melodramatic language, saccharine adjectives, or clichés
- The moralistic close — telling the reader what to think or feel
- The anti-climax — a piece of information that doesn't match the emotional pitch of what preceded it

---

### The bookend technique: construction

1. In your lead, introduce an image, scene, character, or question
2. Allow the body to develop the central argument
3. In the ending, return to that image, scene, character, or question — but transformed by what the reader now knows
4. The transformation is the point: the reader sees the opening differently at the close

Split-anecdote version:
- Open with an incident up to the moment of decision
- Hold the resolution
- Build the piece
- Close with the resolution — now freighted with everything the reader has learned

---

### Linking lead to ending: the quality test

Cover the body of the article. Read only the opening and the ending. Ask:

1. Does the ending pay off what the opening implied?
2. Does the ending add something the opening didn't contain?
3. Could this ending have been written by someone who hadn't read the article? (If yes, it's a generic ending — cut and rewrite.)

If the opening and ending work as a pair — distinct but coherent — the piece has structural integrity.

---

## → Where this subskill leads

**The lead is the first output of the structure decision:**
Load `references/08_story_structure_models.md` if the structure hasn't been decided — the structure model determines the appropriate lead type (Kebab opens with an anecdote; Five-Box opens with a hook; Diamond opens with a specific observation).

**For the prose craft inside the lead:**
Load `references/03_prose_and_voice.md` — register, sentence rhythm, active verbs, and specificity all apply to the lead and ending with extra intensity.

**For revising leads and endings in an existing draft:**
Load `subskills/revision-and-self-editing/revision-and-self-editing.md` — the macro revision pass specifically targets leads (does it hook, orient, and promise?) and endings (does it pay off the opening?).

**For the lead as part of the pitch:**
Load `references/04_pitch_and_query.md` — the query letter's opening hook is written to the same standard as the article's lead. The pitch hook and the article lead can often be the same sentence.
