# Module 01 — Subject and Angle

The single most common reason magazine pitches fail: the writer has a subject, not an angle. This module fixes that.

---

## The distinction that matters

A **subject** is a territory. An **angle** is a specific claim, question, or tension within that territory that a particular magazine reader would want to spend 20 minutes on.

| Subject | Angle |
|---------|-------|
| Electric vehicles | Why the EV charging network is failing rural drivers three years after the government's deadline |
| Aging | The 70-year-olds who are functionally fitter than their 40-year-old children — and what they did differently |
| The housing crisis | Why architects keep designing flats that nobody wants to live in |
| True crime | The victims' families who have started running their own cold case investigations |

The subject tells you what the piece is about. The angle tells you what the piece *argues*, reveals, or promises the reader.

---

## Finding a strong subject

Strong magazine subjects come from one or more of these sources:

**1. A gap in the conversation**
Something is happening that nobody is writing about yet — or nobody is writing about from this angle.

**2. A counterintuitive truth**
Received wisdom is wrong, or only half right. The surprise is the value.

**3. A character who embodies an idea**
One person's story unlocks a bigger truth. Profile journalism works this way.

**4. A moment of change or tension**
Something is shifting. The piece captures the moment before, during, or just after.

**5. A reader problem**
Something the reader is dealing with, worrying about, or curious about — with new information or perspective to offer.

---

## The angle development process

Use these steps in order.

### Step 1: State the subject plainly
Write one sentence: "This piece is about [X]."

### Step 2: Push it with "so what?"
Ask: why would a reader spend 20 minutes on this? If you can't answer that quickly and compellingly, the angle isn't sharp enough yet.

### Step 3: Find the tension or surprise
Every good angle has one of these:
- A contradiction (expected vs actual)
- A conflict (two forces opposed)
- A revelation (something hidden becoming visible)
- A consequence (what this thing means, downstream)

### Step 4: Narrow the claim
Can you write the angle as a single declarative sentence? Not a question — a statement. "The data shows that X is causing Y, and nobody has acted on it."

### Step 5: Check for freshness
Has this angle already been done in the last 12–18 months in the target publication or its direct competitors? If yes, what does your version add?

---

## Stress-testing an angle

Before committing, run these diagnostic questions:

1. **Can I write this as a headline?** If you can't pitch it in 10 words, it isn't sharp enough.
2. **Who would read this and why?** Name a specific type of reader. "Everyone" is not an answer.
3. **What is the central claim?** State it as a sentence. If it requires three sentences, tighten it.
4. **What evidence would I need?** If you can't name at least three sources, scenes, or data points you'd definitely use, you don't have enough material.
5. **Is this the right publication for this angle?** A counterintuitive economics piece is a different sell to the Sunday Times Magazine than to the Spectator. Specificity of market is part of the idea.
6. **What's the opposition or complication?** Good magazine pieces acknowledge that things are not simple. What's the wrinkle, exception, or counterargument?

---

## Matching subject to publication

Magazine editors are commissioning for their reader, not for the writer. Before finalising an angle, establish:

- **Reader profile**: age, interests, income, education level (inferred from the publication)
- **Editorial priorities**: what topics does this publication run regularly? What does it never touch?
- **Tone**: is this publication earnest, ironic, campaigning, detached, celebratory, critical?
- **Length norms**: is this a 600-word front-of-book column or a 4,000-word cover feature?
- **Previous coverage**: have they just run something adjacent? Are they in the middle of a themed issue?

You can infer most of this from reading three or four recent issues carefully.

---

## When the angle is too broad

Signs an angle needs tightening:
- The piece could be 2,000 or 20,000 words — both feel plausible
- You can't name a specific person, moment, or data point you'd open with
- The idea covers multiple disconnected topics
- You keep saying "and also"

Fix: choose one thread and follow it to its end. The other threads become future pitches.

---

## When the angle is too niche

Signs an angle needs widening:
- The audience who cares is fewer than 1,000 people
- The insight doesn't connect to anything broader
- The piece only works if the reader already shares the writer's specialist interest

Fix: find the universal inside the specific. What does this niche thing reveal about something that affects everyone?

---

## Generating angles: practical exercises

**The "nobody knows" exercise**: What do you know that most people in this field, on this topic, or in this reader's life don't? Write that down. That's probably your angle.

**The "against the grain" exercise**: Take the dominant narrative on a subject and ask what the evidence actually says. Is the dominant narrative right? Partially right? Demonstrably wrong?

**The "who's affected" exercise**: Think about who is directly impacted by the thing you want to write about. Find the most specific, most vivid case. That person is probably your way in.

**The "what changed" exercise**: What is different now compared to one year, five years, ten years ago? What caused that change? What does it mean?

---

## Output format for angle development

When working with a user on angle development, produce:

1. **Refined angle statement** — one declarative sentence
2. **Reader promise** — one sentence: what does the reader get from this piece?
3. **Required evidence** — list of three to five specific things needed to write it
4. **Target publication fit** — one or two sentences on where this belongs and why
5. **Alternative angles** — two or three variations if the primary angle has problems

Always confirm the angle before moving to structure (Module 02) or pitch (Module 04).

---

## The news peg: connecting timeless angles to the present moment

Every magazine piece — however evergreen its subject — needs a news peg: a reason to exist right now, rather than six months ago or next year.

News pegs include:
- A new study, report, or data release
- A cultural moment (anniversary, award, death, debut)
- A policy change, legal development, or political event
- A trend reaching critical mass (the "tipping point" signal)
- A recent controversy, scandal, or public debate
- A significant publication (book, film, album, exhibition)

**The peg test**: Why should this piece appear in the [month/issue] edition rather than any other? If the answer is "it could appear any time," the peg is absent — and without a peg, the piece lacks urgency. Find the moment that makes it necessary now.

**Evergreen content**: Some pieces are genuinely timeless — health guides, relationship advice, skills features. These don't need a peg in the same way, but they still need a reason: a new study that has updated the advice, a cultural shift that has made the subject newly relevant, or a reader problem that has intensified.

**The peg without the story**: Sometimes a peg exists but the story doesn't. A press release about a new initiative is a peg. The story is why the initiative matters, who it affects, and what it reveals about a larger problem. The peg is the door; the angle is the room you find inside.

---

## Evergreen vs time-sensitive: calibrating the pitch

| Type | Shelf life | Peg required | Risk of delay |
|------|-----------|-------------|---------------|
| Breaking news / trend | Days to weeks | Essential, strong | High — pitch immediately |
| News feature | Weeks to months | Important | Medium — pitch within 2 weeks of peg |
| Profile / interview | Months | Helpful | Medium — tied to subject's current project |
| Service / how-to | 6–18 months | Desirable | Low — but can become stale |
| Survey / roundup | 12–24 months | Desirable | Low — but watch for superseding developments |
| Evergreen | Indefinite | Optional | Very low — but "why now" still strengthens the pitch |

**The practical rule**: pitch time-sensitive pieces first. File the evergreen idea for when a peg appears.

---

## Generating angles from sources: the "spin-off" method

Every piece of reporting generates more material than one article can contain. The spin-off method extracts maximum value from research and reporting.

After every substantial interview or research session, ask:
1. What is the piece I'm writing now? (The primary angle)
2. What did I learn that is interesting but not directly relevant to this piece? (Spin-off material)
3. What did a source say that pointed toward a completely different story? (New angle)
4. What gap in the existing journalism did my research reveal? (Gap angle)

File spin-offs systematically. The source you interviewed for a healthcare feature may have mentioned something about housing policy in passing — that passing remark is the seed of a separate pitch. A well-maintained idea file built from spin-off material is one of the most valuable assets in a freelance career.

---

## → Where this module leads

**Once the angle is locked, load:**
- `references/02_article_structure.md` — the angle determines the structure; now choose how to build it
- `references/08_story_structure_models.md` — the specific named structure (Kebab, Accordion, Diamond, etc.) that best serves this angle
- `references/05_publication_standards.md` — confirm the angle fits the publication's DNA before going further
- `references/04_pitch_and_query.md` — if pitching before drafting, the angle statement becomes the core of the query letter

**If the angle keeps shifting or won't sharpen:**
The research isn't done. Load `subskills/research-and-interviewing/research-and-interviewing.md` — more reporting almost always resolves an angle that won't firm up.
