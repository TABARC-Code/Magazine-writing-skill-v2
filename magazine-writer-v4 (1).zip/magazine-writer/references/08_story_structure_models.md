# Module 08 — Story Structure Models
**Author: TABARC-Code | Version 2.0**
*Source-validated from: American Journalism Handbook (Zamith), Nieman Storyboard, Poynter Institute, Hennessy (Writing Feature Articles), Hamilton (Uncovering)*

Module 02 covers the editorial hierarchy and article type templates. This module covers the **named structural models** that working journalists use as cognitive scaffolding when building longform and complex pieces. These are not rules — they are tools. Knowing them gives you a vocabulary for diagnosing structural problems and a set of tested solutions.

---

## WHY STRUCTURAL MODELS MATTER

When you sit down with fifty pages of notes and a blank document, the question "what structure should this piece have?" is one of the hardest you'll face. Named structural models are the answers that experienced journalists have developed, taught, and refined over decades.

They also give you a diagnostic language: "this feels like a kebab that's lost its thread" is more useful than "this feels wrong." Name the problem. Apply the fix.

---

## THE SEVEN CORE MODELS

### 1. The Inverted Pyramid

**Shape**: Wide at top (most important), narrowing to least important.

**Use for**: Breaking news, short news items, press releases, any piece where the reader may stop at any point and should have received the most critical information first.

**Structure**:
1. Lead: who, what, when, where, why — the essential facts
2. Supporting detail, most important first
3. Background and context
4. Least important information (can be cut from the bottom)

**Magazine use**: Rare in feature writing, but the underlying principle — lead with your best material — applies everywhere. News features often begin with an inverted pyramid news peg before opening into a fuller structure.

**Failure mode**: The feature writer who buries the most interesting material deep in the piece has unconsciously inverted the inverted pyramid.

---

### 2. The Kebab (Circle / Full Circle)

**Shape**: A central skewer (theme) with pieces of content threaded onto it, returning to the opening.

**Use for**: Trend pieces, human-interest features, profiles with a central case study, any piece where a human subject can carry the thread.

**Structure**:
1. Opening anecdote: a person affected by the trend, issue, or event — specific, scene-set
2. Nut graf: the broader phenomenon this person represents
3. Body: multiple aspects of the phenomenon, each a separate "piece on the skewer"
4. Closing anecdote: returns to the opening person, now understood differently

**Why it works**: The opening character gives the abstract a human face. The reader invests in that person. The closing return pays off that investment.

**The thread**: Every "piece on the skewer" must connect to the central theme. If a section doesn't thread onto the skewer, it doesn't belong in this piece.

**Failure mode**: The closing return feels mechanical — a box-ticking return to the opening person, not a genuine transformation. Fix: ensure the closing moment shows something changed, learned, or revealed by what the reader has just read.

---

### 3. The Accordion

**Shape**: Zooms in and out — central figure / broader context / central figure / broader context.

**Use for**: Complex stories with both an individual human dimension and a systemic or institutional dimension. Science writing, social policy, investigations.

**Structure**:
1. Opening: the central figure in a specific scene (zoom in)
2. Nut graf: the broader phenomenon
3. Section: the central figure's experience (zoom in)
4. Section: expert analysis, data, systemic context (zoom out)
5. Section: the central figure again (zoom in)
6. Section: institutional response, wider pattern (zoom out)
7. Closing: the central figure — transformed by what the reader now knows (zoom in)

**Why it works**: The human dimension keeps the reader emotionally engaged through dense or complex material. The systemic dimension gives the individual story meaning beyond personal interest.

**Failure mode**: The central figure disappears for too long in the "zoom out" sections. Keep the return intervals short — the reader should never forget there is a person at the centre of this.

---

### 4. The Hourglass

**Shape**: Wide at top, narrow in the middle, wide at the bottom.

**Use for**: Sequential event-based pieces where chronological narrative adds clarity; crime and disaster stories; pieces where the timeline matters.

**Structure**:
1. Top: the key decision / finding / consequence (inverted pyramid — most important first)
2. Nut graf: context and stakes
3. Pivot sentence: signals the transition from news to narrative
4. Narrative body: the events in chronological order, with detail and dialogue
5. Bottom: general context or a kicker quote

**The pivot sentence**: This is the structural hinge. Something like: "But the road to that verdict began three years earlier, in a hospital room in Bradford." This sentence closes the inverted pyramid top and opens the narrative bottom.

**Why it works**: Readers who want the key facts get them immediately. Readers who want the full story get it in the second half. Neither is cheated.

**Failure mode**: The pivot sentence is absent or clumsy — the reader feels the jolt of structure rather than moving naturally through it.

---

### 5. The Rick Bragg Five-Box

**Shape**: Five sequential containers, each with a specific job.

**Developed by**: Rick Bragg (Pulitzer Prize winner, New York Times). Taught at Poynter Institute.

**Use for**: Narrative news features, human-interest pieces, any piece where the journalist has a strong central character and a clear story arc.

**The five boxes**:

| Box | Function | Content |
|-----|----------|---------|
| 1 | Hook | Compelling lead — draws the reader in |
| 2 | Nut graf | Summary of the story and its significance |
| 3 | Secondary lead | New facts that sound like a lead; marks the transition to narrative |
| 4 | Support | Detailed evidence, narrative, voices, scenes, data |
| 5 | Kicker | Closing quote or image that leaves the reader with a strong emotion |

**Why it works**: Highly teachable and reliable. Each box has a single, clear job. When a piece isn't working, you can identify which box is failing.

**The kicker**: Box 5 is not a summary. It is an emotional or resonant landing point — a quote, image, or moment that crystallises what the piece meant. Never a "in conclusion" sentence.

**Failure mode**: Box 4 becomes a data dump — all support, no narrative. Keep scenes and human voices alive throughout Box 4.

---

### 6. The Diamond

**Shape**: Narrow at top (specific), wide in the middle (broader context), narrow again at close (back to specific).

**Use for**: Opinion journalism, cultural criticism, personal essays, any piece that begins with a specific observation or experience and expands to a broader argument.

**Structure**:
1. Opening point: a specific anecdote, experience, or observation (narrow)
2. Expansion: the broader cultural, political, or social context this reveals (wide)
3. Evidence and argument: multiple supporting points, each expanding the central claim (wide)
4. Return: closes back on the opening specific, now carrying the weight of the broader argument (narrow)

**Why it works**: Opinion pieces that start with abstract claims feel preachy. The diamond starts with something concrete the reader can see, then earns the abstract claim by building to it.

**Failure mode**: The return to the opening is perfunctory. The reader has done the work of the middle; the ending must repay it. The final specific should feel transformed by the wider argument.

---

### 7. The Braided Narrative

**Shape**: Two or more storylines woven together, converging at a single point.

**Use for**: Complex stories involving multiple characters or cases that illuminate the same theme; historical pieces where past and present interweave; science writing combining research and personal experience.

**Structure**:
- Storyline A: established in the opening
- Storyline B: introduced in the second section
- A and B alternate, each advancing in parallel
- Convergence: the point where A and B meet, illuminate each other, or collide
- Resolution: the meaning of both strands together

**The convergence is everything**: A braided narrative that never truly converges is two separate pieces inadequately joined. The braiding must serve a purpose — the strands must need each other.

**Managing the braid**: Use clear section breaks or transitional signals when switching strands. The reader must always know which strand they're in. Post-it storyboarding (see below) is especially useful for braided structures.

**Failure mode**: One strand is clearly stronger than the other — the reader wants to stay with A but keeps being pulled to a weaker B. Fix: either strengthen B or reconsider whether the braid is the right structure.

---

## THE POST-IT STORYBOARD METHOD

Developed by Danish journalist Line Vaaben (Politiken). Taught at Poynter and in narrative journalism programmes internationally.

**When to use**: Any piece over 1,500 words. Any piece with a narrative structure. Any piece where you feel structurally lost in the material.

**Materials**: Post-it notes (two or three colours), a clear desk or wall.

**Process**:

1. **One-word theme**: Before you touch the Post-its, write down one word that captures the essence of the piece. Not the subject — the emotional or thematic core. This word is your north star; every structural decision is tested against it.

2. **Create the Post-its**: Write one Post-it per scene, section, or element of your piece. One unit per note.

3. **Colour code**: Use different colours for different content types:
   - Colour 1: scenes and narrative (the "meat" — what Vaaben calls "potatoes")
   - Colour 2: background, exposition, data (the "sauce")
   - Colour 3: quotes, expert voices

4. **Arrange on the desk**: Build the structure physically. Move notes around. Ask:
   - Does the opening correspond to the ending?
   - Does the nut graf appear in the right place?
   - Is the mix of colours balanced — enough "potatoes" to carry the reader, enough "sauce" to give it meaning?
   - Does the structure answer the reader's questions in the right order?

5. **Test the structure before drafting**: A ten-minute structural test saves an hour of rewriting. Identify the best opening scene (not necessarily the chronological first). Identify where flashbacks or context fit most naturally. Confirm that the ending resolves the opening question.

6. **For braided narratives**: Use colour to track strands. Visual inspection reveals immediately if one strand is swamping the other.

**The key insight**: "Getting the structure right saves me a lot of time. With longer pieces it is crucial not to get lost." — Line Vaaben

---

## CHOOSING THE RIGHT STRUCTURE

Not every structure suits every story. Use this decision guide:

| Story type | Best structure(s) |
|-----------|------------------|
| Breaking news / short news | Inverted Pyramid |
| Trend piece with human subject | Kebab / Circle |
| Complex systemic + human story | Accordion |
| Chronological event narrative | Hourglass |
| Human-interest narrative news | Five-Box (Bragg) |
| Opinion / cultural criticism | Diamond |
| Multiple characters, same theme | Braided Narrative |
| Profile | Kebab or Five-Box |
| Investigation | Accordion or Kebab |
| Personal essay | Diamond |
| Travel feature | Kebab or Accordion |

**When in doubt**: The Kebab is the most versatile. If you have a compelling human subject and a broader theme, the Kebab will almost always work.

---

## STRUCTURAL DIAGNOSTIC QUESTIONS

When a piece isn't working, ask:

1. **What structure is this piece trying to be?** Name it. If you can't name it, you may not have a structure — you may have a sequence of sections.

2. **Does the opening establish the thread?** Whatever structure you're using, the opening must promise the reader what the piece is about. Can you identify the promise?

3. **Is the nut graf doing its job?** In every structure except the pure inverted pyramid, the nut graf tells the reader why they're reading. Is it present? Is it doing the job?

4. **Do all sections connect to the thread/skewer/theme?** Any section that doesn't connect is either misplaced or belongs in a different piece.

5. **Does the ending pay off the opening?** In every structure that returns to an opening image or character, the return must feel earned. Is it earned?

6. **Try the Post-it test**: Even with a drafted piece, Post-it each section and rearrange. What does the physical structure reveal?

---

## → Where this module leads

**Once the structure model is chosen, build the article:**
Load `references/02_article_structure.md` — the editorial hierarchy (lead, nut graf, body, ending) applies inside whatever structural model you've chosen.

**For the lead and ending that this structure requires:**
Load `subskills/leads-and-endings/leads-and-endings.md` — each named structure (Kebab, Five-Box, Diamond) implies a specific opening and closing approach. Leads-and-endings has the full toolkit.

**For matching structure to article type:**
Load `subskills/article-type-master/article-type-master.md` — the structure model and the article type should reinforce each other. The decision guide at the end of this module maps structures to types; article-type-master gives the type-specific detail.

**If Post-it structuring reveals the angle is wrong:**
Return to `references/01_subject_and_angle.md` — structural problems that resist all structural solutions are usually angle problems. The Post-it test is also an angle test.
