# Module 07 — The Freelance Business
**Author: TABARC-Code | Version 2.0**
*Source-validated from: Peterson & Kesselman-Turkel (Magazine Writer's Handbook), CJR contract research, Society of Professional Journalists, The Open Notebook, Freelancers Union*

Craft gets you in the room. Business keeps you in the game. This module covers everything between "commissioned" and "paid" — and everything between "paid" and "building a sustainable career."

---

## THE BUSINESS REALITY

Magazine writing is a profession. Professionals understand their contracts, protect their rights, negotiate their rates, and manage their relationships. Writers who treat business as an afterthought consistently earn less, own less of their work, and absorb risks that should belong to the publication.

The craft-versus-business split is false. A writer who doesn't understand kill fees may work for months on a piece and receive 25% of the agreed rate. A writer who signs a work-for-hire contract may never be able to reprint or adapt their own work. These are not edge cases — they are standard industry practices that disadvantage writers who don't read their contracts.

---

## PART ONE: RIGHTS AND COPYRIGHT

### What you own

The moment you write something original, you own the copyright. Copyright is not something you register in order to have — it is automatic. Registration strengthens your legal position in a dispute, but the right exists without it.

When you sell an article to a magazine, you are not selling the article. You are licensing a right to publish it. Understanding what right you are licensing — and what you retain — is the most important business decision you make on every commission.

### Rights types

**First Serial Rights (FSR)**
The right to publish your article for the first time in a periodical. After first publication, all rights revert to you. You may then sell it again. This is the traditional and writer-friendly arrangement.

**First North American Serial Rights (FNASR)**
First publication rights limited to North America. You retain the right to publish internationally without restriction.

**One-Time Rights**
The right to publish once, not necessarily for the first time. Used when selling reprints to non-competing publications (e.g., the same piece in a UK magazine and an Australian magazine simultaneously).

**Second Rights / Reprint Rights**
The right to publish a piece that has already appeared elsewhere. Typically sold at a lower rate. A valuable revenue stream for prolific writers — the same piece earning multiple times.

**Electronic Rights**
The right to publish digitally. Beware broad language: "electronic rights" can be interpreted to include website publication, database archiving (LexisNexis, etc.), app publication, and any "not-yet-invented" future medium. Narrow this language wherever possible. If you only intend to allow website publication, write "right to publish on [publication's] website" — not "electronic rights."

**All Rights**
The publication owns the copyright entirely. You may not republish, adapt, or licence the work without their permission. This is the least writer-friendly arrangement. Acceptable only if the rate compensates for the loss of future earning potential, or if the piece has no realistic second life.

**Work-for-Hire**
Legally equivalent to all rights — the publication is treated as the author. You retain nothing. **This is the #1 red flag in any contract.** Never sign a work-for-hire agreement without substantial additional compensation or a very good career reason (e.g., the byline itself has significant value).

### The negotiating position

Ideal: First Serial Rights only, reverting immediately after publication.
Acceptable: Exclusive for a defined period (e.g., 90 days), then reverting.
Negotiate against: All rights, work-for-hire, electronic rights (broad), "all media now in existence or invented in the future."

The negotiating reality: large publications have more leverage. An unknown writer pitching the New Yorker has less room than an established contributor. But negotiating shows professionalism, not impertinence. Many editors will accommodate reasonable requests — they just won't volunteer concessions.

As one journalism professor puts it: "You don't want to sell your rights. You want to rent them to the publication."

---

## PART TWO: CONTRACTS

### The letter of agreement

A contract does not need to be formal to be binding. A commissioning email that specifies subject, word count, fee, deadline, and rights is a contract. Get everything in writing before you begin work.

Minimum terms to confirm in writing before starting:
- Subject and approximate word count
- Fee (and what triggers payment — acceptance or publication)
- Deadline
- Rights being licensed
- Kill fee provisions
- Expenses (if any — see below)

### Kill fees

A kill fee is partial payment for a commissioned piece that the publication decides not to run. It protects the writer from completing work and receiving nothing when the decision not to publish is the publication's, not the writer's.

**Standard kill fee**: 25–50% of the commissioned fee.
**Negotiate for**: 50% minimum; some experienced writers hold out for 100% kill fees.
**Red flag**: A contract with no kill fee provision. Always ask for one to be written in.

Kill fees matter most when:
- Reporting requires significant time investment before the draft is written
- The piece involves travel or expenses
- The subject is time-sensitive and can't easily be resold

**Important**: A kill fee does not mean the publication owns the piece. Once a kill fee is paid, you are typically free to sell the piece elsewhere — confirm this in the contract.

### Payment terms

**On acceptance**: Payment is triggered when the editor accepts the finished piece. This is the writer-friendly arrangement.

**On publication**: Payment is triggered when the piece is published. This can mean waiting months after submission — or longer, if the piece is held. Some publications routinely sit on pieces for six months to a year.

Negotiate for payment on acceptance wherever possible. If a publication insists on payment on publication, consider whether the relationship justifies the cash flow risk.

### Indemnity clauses

An indemnity clause makes you financially liable for legal costs if the publication is sued over your work. Standard boilerplate indemnity clauses are heavily weighted toward the publication.

**Ask for**: Mutual indemnification (both parties indemnify each other for their own errors) rather than one-way indemnification.

**Your liability is limited to what you can prove**: You indemnify the publication for factually accurate, legally compliant work you submitted in good faith. If a publication substantially edits your work and the edit introduces a problem, that should be their liability, not yours.

**Practical protection**: Maintain accurate notes, recordings, and source documents. Your records are your defence.

### Expenses

High-investment reporting (travel, document access, expert translation, data purchase) should be negotiated before the commission is accepted.

Standard practice: agree expenses in advance; obtain receipts for everything; submit with the invoice.

If a piece is killed, expenses already incurred should be covered — confirm this in the contract or at commission.

---

## PART THREE: RATES

### How rates are set

Magazine rates are typically set by the publication, not negotiated from scratch. Most publications have rate bands — ranges within which individual writers are placed. You don't always know which band you're in.

Common rate structures:
- **Per word**: The standard. Ranges from a few pence/cents (regional/specialist) to £3–5/word (major national consumer press). US rates at leading publications: $1–$3/word.
- **Flat fee per piece**: Common for shorter formats (columns, shorts, reviews). Negotiated as a total.
- **Retainer**: A regular payment for a defined volume of work per month. Offers income stability.

### What affects your rate

- Your credits and track record
- The publication's budget
- The complexity and length of the piece
- Exclusivity requirements
- The rights being sought (broader rights = higher rate)
- Whether you have competing offers (rarely stated, but real leverage)

### When to negotiate

Always negotiate, but calibrate to context:
- First commission from a new publication: negotiate once, professionally, then accept the outcome
- Returning writer with track record: you have more leverage; use it
- High-rights-grab contract: rate should compensate for what you're surrendering
- Specialist knowledge that is hard to replace: your leverage is real

**The ask**: "My standard rate for a feature of this length is [X]. Can you match or get close to that?" Most editors can escalate a rate request within a budget band.

### Knowing your floor

Calculate what you need to earn per hour to make freelance writing viable. Factor in:
- Research and interview time
- Draft and revision time
- Admin, pitching, invoicing
- Unpaid reading and development time

A piece that pays well per word but requires three months of investigation may pay less per hour than a short that takes two days. Rate-per-word is not the only measure.

---

## PART FOUR: BUILDING THE FREELANCE CAREER

### Building clips

Your clips (published work) are your portfolio. Editors commissioning you for the first time will want to see evidence that you can do the job.

**Starting out:**
- Write for smaller publications to build a body of work
- Target publications where unsolicited pitches are genuinely read (regional press, specialist interest, trade publications)
- Consider writing for lower-paying publications early in your career to build specific clips in a target sector — but don't stay there indefinitely
- Personal blogs and self-published work have limited value as clips; published work in recognisable outlets has real value

**Building a portfolio:**
- Maintain a personal website with your best published clips
- Organise clips by type and sector so editors can quickly find relevant work
- Keep clips current — an impressive clip from eight years ago carries less weight than recent work

### Specialisation

The most consistent career advice from working magazine writers and editors: develop a specialism.

Generalists can write on anything; specialists are sought out for their subjects. A writer known for covering NHS digital infrastructure, or climate finance, or indie music, will receive commissions that generalists will not.

**How to build a specialism:**
1. Identify two or three areas where your knowledge, experience, or access is genuinely superior
2. Produce the best work you can in those areas, across multiple publications
3. Make your specialism visible — on your website, in your pitch bio, in how you describe yourself
4. Go deeper than the available journalism: read academic papers, attend specialist events, cultivate sources others don't have

**Generalist vs specialist:**
- Specialists earn more per piece in their sector and receive inbound commissions
- Generalists have more flexibility and are less vulnerable to sector downturns
- Most successful mid-career writers are "specialised generalists": known for a sector, capable across many

### Building editor relationships

The pitch is a transaction. The relationship is what produces repeat commissions, priority consideration, and the inside information about what a publication is actually looking for.

**How to build editor relationships:**
- File clean copy on time, every time. This is the foundation.
- Be easy to work with under edits — professional, responsive, not precious about your prose
- Acknowledge good editing when you receive it
- Pitch ideas specifically calibrated to what you know that editor wants
- After a commission, follow up with a brief note — not servile, just professional
- If an editor moves to a new publication, pitch them there

**When an editor edits heavily:**
This is information. Either:
- The piece had problems (diagnose honestly)
- The editor has a strong house-style preference
- Your voice doesn't match their publication (consider whether this is the right market)

Do not dispute edits unless they introduce factual errors or fundamentally change your meaning. Choose your battles carefully and professionally.

**The editor is not your enemy:**
Even heavy editing is, from the editor's perspective, an investment in your relationship. They're trying to make the piece work. Respond to that professionally.

### Managing multiple clients

Successful freelancers treat each publication as a client relationship with its own:
- Tone expectations
- Lead-time requirements
- Communication preferences
- Payment schedule

Keep a simple tracking system:
- Pieces pitched (date, publication, response status)
- Pieces commissioned (deadline, rate, rights, invoiced/paid)
- Expenses outstanding
- Kill fees owed

Chasing payments is a normal part of freelance life. Invoice promptly on acceptance/publication (per contract terms). Follow up professionally at 30 days if unpaid. Escalate at 60 days.

### Diversifying income

Pure magazine writing income is volatile. Strategies to stabilise:

- **Trade press**: lower rates, more regular work, less competition
- **Commissioned books or long-form ebook work**: based on journalism expertise
- **Specialist consultancy**: as a known expert in a sector
- **Teaching and workshops**: journalism schools, writing festivals, online courses
- **Syndication**: selling reprint rights to non-competing publications internationally
- **Ghostwriting**: well-paid, anonymous; compatible with an editorial career

---

## PART FIVE: PROFESSIONAL PROTECTION

### Before you start

- Confirm the commission in writing
- Clarify rights before you invest significant reporting time
- Agree expenses if the piece requires them
- Have a kill fee provision in place

### Media law basics (not legal advice — consult a lawyer for specific situations)

**Libel (defamation):**
A false statement of fact that damages a named living person's reputation. Key protections:
- Truth (justification): if it's true and you can prove it, you have a defence
- Fair comment: opinion clearly presented as opinion, based on true facts
- Privilege: fair and accurate reporting of court proceedings, parliamentary records, official reports

Your practical protection: verify every factual claim; retain all source material; distinguish fact from opinion clearly in copy; reach the subject of any negative claim for response.

**Privacy:**
The reasonable expectation of privacy varies by context. Public figures in their public roles have reduced privacy expectations. Private individuals retain more. When in doubt: is the public interest in this information sufficient to justify the privacy intrusion? Consult your editor.

**Copyright in your sources:**
Quoting from documents, books, or other journalism requires fair dealing (UK) or fair use (US). Brief quotation for the purposes of criticism, commentary, or review is generally protected. Reproducing substantial portions is not.

**Recording laws:**
UK: lawful to record a conversation you are party to without informing the other party (though good practice to disclose). Laws vary by country and US state — check before recording.

### Protecting your records

Keep, for a minimum of three years after publication:
- Interview recordings and transcripts
- Research notes with source and date
- All correspondence with sources
- All correspondence with editors
- Versions of your drafts with timestamps

These are your legal protection if a source disputes a quote, a subject claims libel, or an editor claims a piece was not delivered.

---

## → Where this module leads

**For pitching before the business conversation:**
Load `references/04_pitch_and_query.md` — the pitch must exist and succeed before the contract applies. Business knowledge informs what to accept, but pitch craft gets you there.

**For building the career context that makes contracts negotiable:**
Load `references/09_writer_development.md` — specialisation and track record are what give you leverage in contract negotiations. Unknown writers have less room to negotiate; known specialists have more.

**For understanding the publication type you're contracting with:**
Load `references/05_publication_standards.md` — broadsheet supplements, trade press, and literary magazines have different standard contract terms. Know the landscape before negotiating.

**For managing the freelance business with Kaizen discipline:**
Load `references/06_kaizen_improvement.md` — the improvement loop applies to business practice: tracking pitch strike rates, payment timelines, and contract terms across clients.
