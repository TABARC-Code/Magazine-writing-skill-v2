# Module 09 — Writer Development: Specialisation, Brand, and Resilience
**Author: TABARC-Code | Version 2.0**
*Source-validated from: MasterClass (magazine writing), Fiveable (Magazine Writing and Editing Unit 18), Expert-ish Freelancer, Peterson & Kesselman-Turkel, Kaizen principles*

The craft is what you produce. The career is what sustains your ability to produce it. This module covers the strategic and psychological dimensions of developing as a professional writer — building a specialism, developing a personal brand, maintaining editor relationships, and protecting your ability to work through difficulty.

---

## PART ONE: SPECIALISATION

### Why specialists outperform generalists

A generalist can write about anything competently. A specialist is sought out for their subject. The distinction matters for income, opportunity, and quality of work.

Specialists receive:
- **Inbound commissions** — editors who need their subject come to them
- **Higher rates** — specialist knowledge commands a premium
- **Better access** — sources know and trust the beat writer
- **Deeper pieces** — accumulated knowledge produces better journalism

ESPN writer Brian Windhorst covered all professional sports competently. He strategically chose to focus on basketball. He credits that decision for his rise within the organisation. The magazine no longer exists; the specialist does.

### Identifying your specialism

A specialism must sit at the intersection of three things:

1. **Knowledge or access you have that others don't**: What do you understand, have experienced, or have relationships in that most writers don't? Medical training. A decade in a specific industry. Fluency in a second culture. Deep access to a community.

2. **A subject area with a sustainable market**: Is there a publication (or multiple publications) that regularly commissions this subject? Are there enough angles to sustain a career, not just one piece?

3. **Genuine interest**: A specialism you find dull will produce dull work. You are going to read everything written in this field, cultivate sources, attend events, and think about it constantly. It must engage you.

### Building the specialism

**Phase 1 — Establish presence (first 6–12 months)**
- Write two to three strong pieces in the target area across different publications
- These clips establish your credibility in the specialism
- They need not be the best-paying commissions — they are investments

**Phase 2 — Go deeper than the available journalism**
- Read academic papers, specialist trade publications, and books that general journalists don't read
- Attend specialist events, conferences, and meetings
- Cultivate sources that other journalists haven't reached yet
- Develop a point of view — not just knowledge, but perspective

**Phase 3 — Make the specialism visible**
- State your specialism clearly on your website and in pitch bios
- Ensure your clips in the specialism are prominently displayed
- When editors mention your name, the specialism is what they should think of

**Phase 4 — Defend and deepen**
- Stay current; a specialism that becomes stale loses its value
- Pitch within the specialism regularly; don't let the beat go quiet
- Be the person editors call when the subject breaks as news

### Generalist vs specialist: the practical decision

Pure generalism is harder to sustain as a career than it was in the print era. The digital age makes specialists more findable and more commissionable.

The practical sweet spot: **the specialised generalist**. A writer with one or two deep beats who also writes competently across a broader range. The specialism provides the inbound commissions and the identity; the generalist range provides flexibility when the beat is quiet.

---

## PART TWO: PERSONAL BRAND

### What a writer's brand is

Your brand is what editors think of when they hear your name, and what they can find when they search for you. It is not separate from your work — it is your work, made visible and navigable.

Components:
- Your specialism or distinctive angle
- The publications associated with your byline
- Your online presence (website, clips, professional social media)
- Your reputation for reliability, ease to work with, and accuracy

### The writer's website

A professional website is not optional. It is how editors verify you are who you say you are, check your clips, and decide whether to commission you.

Minimum requirements:
- Clear statement of who you are and what you cover
- Clips: your ten best published pieces, clearly labelled by publication and date
- Contact information
- Brief bio, written in the third person (for easy copying into contributor notes)

Good practice:
- Organise clips by specialism or publication type
- Update every time a significant piece is published
- Make it easy to read on mobile

### Professional social media

LinkedIn and Twitter/X remain the primary professional platforms for journalists (as of 2024–25). Use whichever is most active in your sector.

Principles:
- Your public presence should reflect what you want to be commissioned for
- Engage with your specialist subject — share and comment with intelligence
- Build relationships with editors, other journalists, and sources by being genuinely useful
- Do not post anything you would not want to appear in a profile of you

---

## PART THREE: EDITOR RELATIONSHIPS

### The foundation: reliability

The single most important thing you can do for an editor relationship is file clean, accurate, on-time copy. Everything else is secondary.

"Clean copy" means:
- Factually accurate
- Within the agreed word count
- Formatted to the publication's requirements
- Delivered before the deadline

Editors work under pressure. A writer who is consistently reliable removes a category of problem from their day. That is remembered.

### Becoming a regular

Most magazine commissions go to writers the editor already knows. Breaking into a regular working relationship requires:

1. **A strong first piece** — do everything possible to make the first commission excellent
2. **Prompt, professional follow-through on edits** — respond quickly, implement changes accurately, do not argue unless a change introduces a factual error
3. **A quick thank-you and follow-up pitch** — a brief email after publication ("Thanks for a great experience — I've been thinking about [next idea]") keeps you top of mind
4. **Reading what the publication runs** — your next pitch should show you paid attention to what they commissioned

### Working with editorial changes

Editors change copy. Sometimes significantly. The professional response to edits you disagree with:

1. **Read all changes before reacting** — the full picture is often less alarming than a first impression
2. **Implement factual corrections without discussion** — these are always correct
3. **Implement style and tone changes unless they introduce errors** — this is the editor's job
4. **Query changes that introduce factual errors** — politely, with the specific correction
5. **Query changes that significantly alter your meaning** — once, clearly, professionally
6. **Accept the editor's final decision** — pick battles carefully; losing the relationship over a sentence is rarely worth it

The exception: if an edit introduces a claim you cannot stand behind, or attributes to you a position you don't hold, you have the right to withdraw your byline. This is rare and should be the last resort.

### When the relationship is difficult

Editors who give no feedback, change pieces beyond recognition, or commission and then kill without explanation are part of the landscape. Strategies:

- Ask for feedback when a piece is killed — a brief, professional request for guidance
- If feedback is consistently absent and pieces are regularly killed, consider whether this is the right relationship to invest in
- Never vent publicly about a specific editor or publication — the industry is small and connected

---

## PART FOUR: RESILIENCE AND THE WRITER'S PSYCHOLOGY

### Rejection is data, not verdict

Every working magazine writer experiences rejection regularly. Writers who are published in prestigious outlets are rejected regularly. Rejection is structural — editors have limited slots, limited budgets, and existing relationships — not a verdict on talent or worth.

The Kaizen response to rejection: root-cause analysis (why was this rejected?), one actionable fix, apply to next attempt. Not self-blame. Not catastrophising. Pattern recognition and incremental correction.

### Imposter syndrome

The feeling that you are not qualified to be doing this, that your acceptance into any room is a mistake, and that you will soon be found out — is near-universal among writers, including very successful ones. It is not a sign of inadequacy. It is a sign of self-awareness in a field where standards are high.

Practical management:
- Focus on the work, not the self-assessment of the work
- Track your publishing record objectively — what you have produced, not what you feel
- Recognise that the feeling does not disappear with success; it changes form
- Use the Kaizen standards document as an objective record of improvement that counters the subjective feeling

### Writer's block: the practical toolkit

Writer's block is not a single thing. It has specific causes with specific solutions.

**Cause 1: You don't know what the piece is about**
Solution: Do not draft. Go back to Module 01 (Subject and Angle) and state the angle in one sentence. You cannot write what you cannot state. The block is a signal that the thinking isn't done.

**Cause 2: You don't know where to start**
Solution: Don't start at the beginning. Write the section you are most certain about — any section. The beginning can be written last. Many professional writers write the ending, the strongest middle section, and then the opening, in that order.

**Cause 3: You're waiting to write until the draft is perfect**
Solution: Write a deliberately bad first draft — one where you give yourself explicit permission to be clumsy, obvious, and imprecise. Get the material down. The revision is where quality happens; the first draft is where material happens.

**Cause 4: The subject feels overwhelming**
Solution: Break it into the smallest possible unit. Not "write the feature" — "write this one scene." Not "write this scene" — "describe what this room looked like." Start with the smallest possible actionable unit and build from there.

**Cause 5: Avoidance through endless preparation**
Solution: Set a research deadline. Research until [date], then draft. The temptation to keep researching is sometimes the temptation to avoid the vulnerability of drafting. More research rarely solves a drafting problem.

**Cause 6: Exhaustion or depletion**
Solution: Stop. Read — not for work, but for pleasure. Walk. Sleep. The creative well refills; forcing it when empty produces low-quality work that costs more in revision time than the rest would have.

**Cause 7: Fear of the subject or the source**
Solution: Name the fear. Is the piece in territory that feels ethically uncomfortable? Does the subject feel too close to personal experience? These are legitimate editorial and psychological concerns, not productivity failures — address them directly.

### Sustaining a long-term practice

Magazine writing is not a sprint. The writers who sustain careers over decades do so by:

- **Reading widely and constantly** — not just journalism; fiction, history, science, whatever feeds the mind
- **Filing ideas systematically** — keeping a running idea file; the idea you dismiss today may be the commission you need in six months
- **Maintaining relationships even when not actively pitching** — a light touch, a social media interaction, a note about a piece they published
- **Resting deliberately** — treating rest as part of the professional practice, not an admission of weakness
- **Never stopping learning** — new forms, new platforms, new subject areas; the writer who stops developing calcifies

### The Kaizen commitment in writer development

Every dimension of this module — specialism building, brand development, editor relationships, resilience — operates on the Kaizen principle: incremental, deliberate improvement, tracked and adjusted over time.

One editor relationship built per quarter. One specialism deepened per year. One website update per month. One new publication pitched per month. These are not dramatic commitments — they are the small, consistent actions that compound into a career.

The writer who improves 1% per piece, and 1% per relationship, and 1% in their understanding of the market, will be unrecognisable in five years. That is the practice. That is Kaizen.

---

## → Where this module leads

**For the improvement loop that operationalises development:**
Load `references/06_kaizen_improvement.md` — the personal standards document, improvement targets, and compound effect table are the practical engine of what this module describes strategically.

**For the business mechanics of career building:**
Load `references/07_freelance_business.md` — specialisation and brand lead to better contracts and negotiating positions. The career strategy and the contract strategy are inseparable.

**For calibrating your specialism to specific publications:**
Load `references/05_publication_standards.md` — knowing which publications cover your specialism, and at what register and rate, is part of specialism strategy.

**For turning specialism into a pitch strategy:**
Load `references/04_pitch_and_query.md` — specialism makes pitches stronger, and pitch tracking reveals whether the specialism is landing as intended.
