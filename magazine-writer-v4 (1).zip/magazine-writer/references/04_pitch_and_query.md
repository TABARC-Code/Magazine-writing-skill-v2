# Module 04 — Pitch and Query

The query letter is the angle's first test. If the idea can't be pitched in 300 words, it isn't sharp enough yet. This module covers the full pitch process from concept to commission.

---

## What editors are actually reading for

When an editor opens a pitch, they are asking four questions in roughly this order:

1. **Do I know this writer?** (reputation, credits, reliability)
2. **Is this right for our readers?** (subject, angle, register)
3. **Can this person actually write it?** (the pitch itself is the sample)
4. **Is the timing right?** (news peg, editorial calendar, recent coverage)

A pitch that fails any of these four tests is rejected. Most rejections are from 1 and 2. A perfect query letter from an unknown writer pitching the wrong subject to the wrong publication is still a rejection.

---

## The query letter: anatomy

A professional query letter is 200–350 words. It contains:

**1. The hook** (1–3 sentences)
Open the way the article would open. This is not a summary — it is the first demonstration that you can write.

**2. The angle statement** (1–2 sentences)
A clear, declarative statement of what the piece argues, reveals, or delivers. One sentence is better than two.

**3. The why now** (1–2 sentences)
Why does this piece need to exist at this moment? Is there a news peg, an anniversary, a cultural moment, a trend that gives it urgency?

**4. The structure / approach** (3–5 sentences)
What kind of piece is this? Who will you speak to? What evidence or material will anchor it? Give enough specificity that the editor can see the piece being assembled.

**5. The fit** (1–2 sentences)
Why this publication? Name a specific section, column, or slot where you see it landing. Show you've read the magazine.

**6. The credentials** (2–4 sentences)
Who are you and why are you the person to write this? Relevant credits, specialist knowledge, access. Don't list everything — choose the most relevant two or three.

**7. Word count and deadline flexibility** (1 sentence)
Offer a length range and indicate you can work to their schedule.

---

## Query letter template

```
[Salutation — use the editor's name. Never "Dear Editor."]

[Hook: open the way the article opens. One vivid, specific sentence or two.]

[Angle statement: what this piece argues or reveals, in one sentence.]

[Why now: the news peg, trend, or urgency factor. One to two sentences.]

[The piece: who you'll speak to, what evidence anchors it, what type of feature it is. Three to five sentences.]

[Publication fit: one sentence naming the specific section or slot. Show you've read the magazine.]

[Credentials: two or three relevant credits or qualifications. One to two sentences.]

[Practical close: proposed word count, willingness to discuss, contact details.]

[Sign-off]
```

---

## Annotated example

> Dear [Editor's name],
>
> Every week, Emma Rees spends six hours travelling to hospital appointments she could have attended in twenty minutes if the NHS app worked as promised.
>
> For *[Magazine]*, I'd like to write a 2,000-word feature on why the NHS's flagship digital access programme is failing the patients it was designed to help most — those in rural areas with complex, ongoing needs.
>
> The programme launched eighteen months ago to significant political fanfare. Since then, patient complaints in rural CCGs have risen 34% year-on-year, and a leaked internal review suggests the rollout team knew about the accessibility barriers before launch.
>
> The piece would be structured around three patients whose experiences illustrate the systemic failure, anchored by data from the internal review and responses from the NHS Digital team and two independent health technology researchers. I'd approach it as a narrative-led investigation, under 2,000 words, suitable for the *[Section name]* slot.
>
> I write regularly for *[Publication A]* and *[Publication B]*. I covered NHS digital infrastructure extensively in 2022–23 and have contacts within NHS Digital from that period.
>
> Happy to discuss scope, timing, or approach. The piece could be ready within three weeks of commission.
>
> [Name, contact details]

**What works**: specific character in the hook, clear claim in the angle statement, evidence of access and existing research, specific section placement, tight credentials.

---

## Matching pitch to publication

A pitch that is right for the Guardian Weekend is not automatically right for the Sunday Times Magazine. Know the difference before sending.

Questions to research before pitching:

- What is the publication's house angle on this subject? (If they've just run something similar, don't pitch it.)
- What length do they typically commission at?
- Do they prefer narrative features or structured explainers?
- Is the subject politically aligned with their editorial line, or does the pitch need to be framed carefully?
- Do they accept unsolicited pitches at all? (Many consumer magazines don't.)

---

## Following up

Wait at least two weeks before following up. A single brief follow-up is acceptable. Two is the maximum. After two follow-ups with no response, the answer is no.

Follow-up format: three sentences. Remind them of the pitch subject and date. Ask if they'd like more information. Indicate you're happy to discuss.

---

## When a pitch is rejected

Rejection reasons rarely appear in rejection letters. Common real reasons:

- Recently commissioned or running something similar
- Wrong length for available slots
- The subject is right but the angle is off
- The publication doesn't know the writer
- The section it was pitched for is closed or changing

**What to do**: revise the angle or the market, not necessarily the idea. A rejected pitch from a broadsheet might be right for a specialist magazine. A piece rejected for the feature slot might work as a shorter column.

---

## Pitching without a complete draft

Most professional magazine writers pitch before writing. The query letter sells the angle and the writer's ability. The draft comes after commission. This means:

- The pitch must be specific enough that the editor can see the piece
- You must have done enough reporting to know the piece is viable
- You should not promise sources, data, or scenes you haven't confirmed you can access

If you pitch without a complete draft, have at least one confirmed source and one concrete piece of evidence in hand before sending.

---

## Simultaneous submissions

Pitching the same idea to multiple publications at once is standard practice for unsolicited pitches, but:

- Never pitch two competing publications (e.g., Guardian Weekend and Observer Magazine) simultaneously
- If a publication responds with interest, notify the others immediately
- If you have a working relationship with an editor, give them a window of exclusivity before sending elsewhere

---

## The pitch as writing sample

The query letter is not an administrative task. It is a writing sample. Editors read it to assess whether you can write the piece — not just whether you have a good idea.

Apply Module 03 to your query letters:
- The hook sentence should be as carefully crafted as an article lead
- The angle statement should be as sharp as the piece's nut graf
- The prose should be clean, specific, and active throughout
- No clichés, no passive voice drift, no vague claims

A competent idea pitched clumsily reads as a competent idea that the writer cannot execute. A strong pitch for a moderate idea reads as proof that the writer can deliver.

---

## Pitching for specific sections and slots

Editors don't commission "articles" — they commission pieces for specific slots with specific length, register, and format requirements.

Before pitching, identify:
- **The specific section**: front-of-book, long read, opinion, column, interview, service feature
- **The length norm for that slot**: count words in published examples
- **The tone and format**: does this slot use subheadings? First person? Data?

Name the slot in your pitch: "I see this as a 1,500-word piece for the [section name] slot, structured as a narrative feature with three case studies." This reduces the editor's decision-making effort and demonstrates that you've read the publication.

---

## Cold pitching vs warm pitching

**Cold pitch**: approaching an editor you have no prior relationship with, on a publication you haven't written for.

Challenges:
- Your pitch competes with known contributors for attention
- The editor has no prior evidence of your reliability
- Response rates are lower

How to improve cold pitch performance:
- Address a named editor (research who commissions the specific section)
- Reference a specific recent piece from the publication that your pitch connects to or extends
- Include two to three directly relevant clips, not your entire CV
- Make the pitch itself do the work — no preamble, straight to the hook

**Warm pitch**: approaching an editor you have worked with before, or where you have a warm introduction.

Use the relationship: "Following on from the piece I wrote for you last March, I've been looking at..." saves the editor context-setting time and reminds them of a successful working relationship.

---

## Pitching internationally

Pitching to publications in other countries works the same way — with calibration:

- **Register**: British, American, and Australian publications have different editorial cultures, vocabulary standards, and tonal norms
- **The "why this reader" question**: why would a Canadian magazine reader care about a story based in Glasgow? You need an answer
- **The local angle**: strong international pieces usually have a local dimension — the global story as it manifests locally

Rights note: when selling to publications in different countries, clarify which geographic rights you're selling. First North American Serial Rights does not cover UK publication.

---

## Tracking pitches: the pitch log

Professional freelancers track every pitch. Minimum tracking:

| Date | Publication | Section | Angle (1 line) | Status | Notes |
|------|-------------|---------|----------------|--------|-------|
| 12 Jan | Guardian Weekend | Long read | Why rural EV charging is failing | Sent | |
| 15 Jan | Stylist | Service | Managing anxiety at work | Rejected | "Not right for us now" |
| 20 Jan | FT Weekend | Profile | Simon Calder — travel journalism | Commissioned | Due 10 Feb |

Review your pitch log monthly:
- What is your commission rate overall?
- Which publications are accepting most consistently?
- What types of pitch are performing better?
- What is the most common failure mode?

This is Kaizen applied to pitching: measure, identify patterns, adjust systematically.

---

## → Where this module leads

**When a commission comes back — immediately load:**
Load `references/07_freelance_business.md` — before you start work, confirm rights, kill fee, payment terms, and expenses in writing. The pitch becomes a contract.

**Before pitching — confirm the angle is sharp:**
Load `references/01_subject_and_angle.md` — a pitch built on a soft angle will be rejected regardless of how well-written the query letter is.

**For building a sustainable pitching strategy:**
Load `references/09_writer_development.md` — specialisation, personal brand, and editor relationships are what convert one-off pitches into a regular commissioning relationship.

**After repeated rejections from the same publication or pitch type:**
Load `references/06_kaizen_improvement.md` — the Kaizen pitch log and root-cause analysis for rejection patterns.
