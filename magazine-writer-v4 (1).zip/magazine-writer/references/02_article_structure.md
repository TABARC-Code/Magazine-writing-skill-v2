# Module 02 — Article Structure

Structure is not template-following. It is the sequence of decisions that gets the reader from the opening to the ending without losing them, without confusing them, and without wasting their time.

---

## The editorial hierarchy

Every professionally published magazine article has this hierarchy, whether visible or implied:

1. **Headline** — promises the piece; earns the click or the turn of the page
2. **Deck / standfirst** (optional) — expands the headline; usually 20–40 words; often written by the editor, not the writer
3. **Byline**
4. **Lead** — first paragraph(s); hooks the reader; does not explain everything yet
5. **Nut graf** — explains why the reader is reading; provides context and stakes
6. **Body sections** — develops the argument, narrative, or information in sequence
7. **Subheads** — structural signposts; useful for longer pieces (1,500+ words)
8. **Supporting material** — quotes, data, scenes, anecdotes, expert voices, sidebars
9. **Kicker / ending** — lands the piece; pays off the opening promise

---

## The lead

The lead is the most important part of the piece. It does three jobs:

1. **Hook** — gives the reader a reason to continue
2. **Orient** — establishes the world of the piece without fully explaining it
3. **Promise** — implies what is coming without giving it away

### Lead types

**Anecdote lead**: Opens with a specific scene, moment, or character. Most common in feature writing. Works when the anecdote is genuinely compelling and connects directly to the piece's central claim.

**Declarative lead**: Opens with a bold, specific statement of fact or claim. Works for pieces where the insight itself is the hook.

**Question lead**: Use sparingly and only with a question the reader is already asking. Avoid rhetorical questions that feel cheap.

**Scene-setting lead**: Establishes place, atmosphere, or situation before introducing a person or argument. Works for travel, profile, and narrative features.

**Contrast lead**: Opens with a juxtaposition — what was expected vs what happened, what was then vs what is now.

### Lead failures to avoid

- Starting with "In recent years..."
- Starting with a dictionary definition
- Starting with a quote (usually)
- Starting with the writer's own arrival at a location
- Burying the actual opening in paragraph three

---

## The nut graf

The nut graf (nut paragraph) is the paragraph that tells the reader why they're reading. It follows the lead and provides the frame for the entire piece.

A good nut graf answers:
- What is this piece about?
- Why does it matter now?
- What will the reader know, understand, or be able to do by the end?

It is not a summary of the article. It is the explicit statement of stakes and purpose. In a 2,000-word piece, it often appears in paragraphs 3–5. In a longer investigation, it can come later.

**Nut graf test**: Cover the rest of the article. Read only the lead and the nut graf. Does the reader now know what they're in for? If not, the nut graf isn't doing its job.

---

## Body structure: sequencing principles

Regardless of article type, body sections should follow one of these logics:

**Narrative sequence**: What happened, in order. Best for first-person, profile, and investigative pieces where events unfold in time.

**Argumentative sequence**: Claim → evidence → complication → resolution. Best for opinion, analysis, and investigative features.

**Thematic sequence**: Chunk related material together. Each section handles one aspect of the subject. Best for explainers and how-to pieces.

**Escalation sequence**: Start with the most accessible or least controversial point, build to the most challenging or significant. Best for pieces that need to bring the reader along gradually.

---

## Article type templates

### News feature (800–2,000 words)
1. Lead: the news moment or situation
2. Nut graf: context and stakes
3. Background: what led here
4. Expert/witness voices
5. Wider implications
6. What happens next

### Profile (1,500–4,000 words)
1. Scene-setting lead: the subject in a revealing moment
2. Nut graf: why this person, why now
3. Current project or achievement (the hook)
4. Background and formative experience
5. Defining challenge or turning point
6. How they work / what they believe
7. What's next
8. Closing image or quote that returns to the opening

### Investigative feature (2,000–6,000 words)
1. Opening scene or case study
2. Nut graf: the problem and why it matters
3. Background: how we got here
4. The evidence (in sections)
5. Who knew / who's responsible
6. The counterargument or institutional response
7. The wider implications
8. The human cost or call to action

### Opinion / column (600–1,200 words)
1. Hook: the specific thing prompting the column
2. The claim
3. Evidence or illustration (two or three strong examples)
4. The counterargument (acknowledge, then rebut)
5. The conclusion (restate the claim with force)

### How-to / service feature (800–2,000 words)
1. Lead: why this matters / the problem it solves
2. What you need to know before starting
3. Numbered or sequenced steps (each with context, not just instruction)
4. Common mistakes or complications
5. The payoff or result

### Travel feature (1,000–3,000 words)
1. Evocative scene-setting lead
2. The animating idea (why this place, why now, what the piece is really about)
3. Journey and discovery sections (alternating scene and reflection)
4. Practical or cultural insight woven in
5. Ending that returns to the animating idea

### Interview feature (1,000–3,000 words)
1. Scene: where the interview takes place, the subject's presence
2. Nut graf: who they are and why readers should care
3. The conversation in thematic sections (not chronological question-and-answer)
4. Background and context woven in
5. A revealing moment or exchange
6. Closing quote or image

---

## Subheads

Use subheads in any piece over 1,500 words. Rules:

- A subhead is a signpost, not a teaser. The reader should know what the section covers.
- Subheads should not repeat language from the preceding or following paragraph.
- Keep subheads to five words or fewer where possible.
- Do not use subheads as a substitute for transitions — the prose must flow with or without them.

---

## The ending

The three functions of a good ending:

1. **Closes the loop**: returns to an image, character, or question from the opening
2. **Lands the central claim**: crystallises what the piece argued or revealed
3. **Leaves the reader with something**: a thought, a feeling, a question worth carrying

### Ending failures to avoid

- Summarising what you just said ("In conclusion...")
- Ending on someone else's quote when the writer should be making the final move
- The "and so we see that..." wrap-up
- Trailing off without resolution
- Ending on a rhetorical question when a statement would be stronger

---

## Structural diagnostic questions

Before finalising structure, check:

1. Does the lead make a reader want to read the second paragraph?
2. Does the nut graf appear before the reader has given up?
3. Does each body section do one clear job?
4. Is there a section that could be cut without the piece losing anything essential?
5. Does the ending pay off the opening?
6. Would a subheaded version of this piece make sense? (i.e., are the sections genuinely distinct?)

---

## Advanced nut graf technique

The nut graf is the most-discussed structural element in magazine journalism. Its treatment above covers the basics. Here is the deeper picture, validated from Nieman Storyboard and The Open Notebook research.

### What a nut graf can be

A nut graf is not always a single paragraph that summarises the piece. It can be:

- **A single sentence**: in a short, tight piece with a strong lead, one sentence is enough
- **A multi-paragraph section**: in a complex investigation or longform narrative, the "nut section" may run 200–300 words
- **A single quote**: a source's statement that captures the story's significance can serve as the nut on its own
- **Absent**: in a strong narrative where the story itself carries its meaning, an explicit nut may be unnecessary and intrusive. The narrative must be genuinely strong enough to stand without it.

### The pre-draft nut graf

One of the most effective techniques for beating structural drift: **write the nut graf before the draft**.

As Erika Check Hayden (director, UC Santa Cruz science communication programme) teaches: writing the nut graf before sitting down to draft forces the writer to answer the question "what is this piece actually about?" before committing to a structure.

A nut graf you cannot write clearly before drafting is a signal that the angle is not clear enough yet. Go back to Module 01.

### The five-sentence nut graf technique

For features where the nut needs to do significant work (longform, complex investigations):

1. **What is happening**: the core event or situation, stated plainly
2. **Why it matters**: the stakes — what is at risk, what could change
3. **Why now**: the news peg or current relevance
4. **Who is affected**: the human dimension of the claim
5. **What this piece will do**: the implicit promise to the reader

Not every nut needs all five. But running through this checklist reveals what's missing.

### The nut as promise and contract

The nut graf makes a promise to the reader: this is what the piece is going to deliver. Every section that follows must serve that promise. If material in the body of the piece doesn't connect to what the nut promised, that material is either in the wrong piece or the nut is wrong.

A common structural failure: the nut promises X, but the body delivers Y and Z, with X mentioned only briefly. Readers feel cheated without knowing why. The piece has broken its contract.

### Nut graf position

In a news feature: typically paragraphs 2–4.
In a profile: typically paragraphs 3–6 (after enough scene-setting to earn it).
In a longform investigation: may come as late as paragraph 8–10 if the opening scene is doing complex work.
In a narrative piece: may be embedded in the narrative rather than stated explicitly.

Test: cover everything after the nut graf. Read only the lead and the nut. Does the reader now know what they're in for and why it matters? If not, the nut is in the wrong place or hasn't been written yet.

---

## Additional article type templates

### Review / Criticism (300–1,500 words)
1. **Hook**: the specific work and the arresting first impression — not "this is good/bad" but something specific that makes the reader feel the encounter
2. **Context**: what this work is, who made it, where it sits in the field — necessary but brief
3. **Central claim**: what the critic thinks, stated clearly. Not hedged. Not "on the one hand / on the other."
4. **Evidence**: specific passages, scenes, moments, or technical choices that support the claim — this is the argument
5. **Complications**: what the work does well even if you are criticising it; where your claim has limits
6. **Verdict**: the final recommendation or judgement, earned by what preceded it

**The critic's job**: An opinion stated as opinion, based on direct engagement with the work, argued with specific evidence. Not a summary. Not a plot synopsis. The reader should know what the work is and what to think about it — those are two different things and both must be delivered.

**Common failures**:
- Review that is 80% plot/content summary with two sentences of opinion at the end
- Hedged verdict that commits to nothing
- Criticism without evidence — "the writing is poor" without showing a specific passage where it is poor
- Failure to engage with what the work is trying to do on its own terms

---

### The Q&A Format (800–3,000 words)
When an interview is published as Q&A rather than shaped into a feature, it must still be edited — not transcribed.

**When Q&A is the right format**:
- The source is sufficiently well-known that their voice is the value
- The exchange itself contains genuine drama or revelation
- The publication has a Q&A slot that rewards the format
- The source's way of speaking is part of the story

**Editing a Q&A**:
- Cut questions that produced flat answers — a Q&A is not an obligation to include everything
- Reorder questions thematically if the conversation rambled
- Tighten answers: cut filler, redundancy, and anything that doesn't serve the reader
- Never change meaning in tightening; cut rather than rewrite
- Write a brief scene-setting intro: where, when, who — the physical and human context

**The Q&A intro**:
Even in Q&A format, the piece needs an opening that earns the conversation. Three to five sentences establishing the subject, why they matter now, and the essential observation about their presence or context.

**Common failures**:
- The unedited transcript masquerading as a Q&A
- Flat questions that reveal no preparation
- No scene-setting intro — the reader arrives cold
- Including questions that the answers didn't justify

---

### The Listicle / Numbered Feature (500–2,000 words)
Widely derided, widely read, and regularly commissioned by every type of publication. The craft challenge is making it something more than a list.

**What makes a numbered feature work**:
- Each item must genuinely justify its number — not padding to reach a round figure
- Each item should be substantively different from the others — not variations on the same point
- Each item needs its own mini-structure: claim + evidence + example
- The whole must be ordered: strongest first, or building in some logical sequence
- The frame (the number, the category) should be genuine, not arbitrary

**Length calibration**:
- 5–7 items: suits most online formats
- 10 items: works if genuinely distinct; risks padding
- 25+ items: only if each is brief and the comprehensive list is genuinely the value

**Common failures**:
- Padding to reach the headline number
- Items that are really sub-points of the same item
- No evidence or specificity — assertions presented as facts
- Ordering that neither builds nor ranks — purely arbitrary sequence
- A listicle that would have been a better feature article

---

## → Where this module leads

**For named structural models (Kebab, Accordion, Five-Box, Diamond, Braided):**
Load `references/08_story_structure_models.md` — extends this module with the full taxonomy of named structures and the Post-it storyboard method.

**For lead and ending craft:**
Load `subskills/leads-and-endings/leads-and-endings.md` — deep operational guidance on every lead type, ending type, anecdote construction, and the bookend technique.

**For type-specific structural templates:**
Load `subskills/article-type-master/article-type-master.md` — each article type (profile, how-to, investigation, narrative, etc.) has its own structural logic beyond the generic templates here.

**Once structure is established, move to prose:**
Load `references/03_prose_and_voice.md` — register, sentence craft, transitions, quote handling, scene-setting.

**If the structure feels wrong and keeps resisting:**
Return to `references/01_subject_and_angle.md` — structural problems are often angle problems in disguise.
