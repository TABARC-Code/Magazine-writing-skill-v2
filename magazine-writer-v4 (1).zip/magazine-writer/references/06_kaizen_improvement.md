# Module 06 — Kaizen: Continuous Improvement for Writers
**Author: TABARC-Code | Version 2.0**
*Synthesised from: Kaizen methodology applied to the craft of magazine writing*

> *"I wonder if I shall ever learn to write." — R. L. Stevenson, revered as a great stylist*

The magazine writer who believes they have finished learning has stopped developing. The discipline of Kaizen — continuous, incremental, systematic improvement — applies to writing craft as directly as to manufacturing or software. This module integrates the Kaizen philosophy throughout the magazine-writing workflow.

---

## THE KAIZEN PRINCIPLE IN WRITING

**Many small improvements beat one big change.**

Writers who wait for a breakthrough — the moment when everything clicks — are waiting for something that rarely arrives. Writers who improve one specific thing per piece, consistently, compound those gains into a practice that transforms over time.

Kaizen asks not "how do I become a great writer?" but "what is one specific thing I can do better in this piece than I did in the last?"

---

## THE FOUR PILLARS APPLIED TO WRITING

### 1. Continuous Improvement — Leave Every Draft Better

**The writing equivalent of "always leave the codebase better than you found it":**

Never file a piece without having improved at least one thing you identified as a weakness in the previous piece. Name the improvement before you start. Check whether you achieved it when you finish.

**The three-pass iteration model** (directly from Kaizen):
- **Pass 1**: Make it work — does the piece say what it needs to say?
- **Pass 2**: Make it clear — can the reader follow it without effort?
- **Pass 3**: Make it strong — is every element as good as it can be?

Do not attempt all three in one pass. The writer who tries to perfect on the first draft produces less good work than the writer who iterates.

**Incremental improvement targets** (use one per piece):
- This piece: leads. Study the lead; improve it beyond what you'd normally accept.
- Next piece: transitions. Are they invisible? Fix every one that isn't.
- Next piece: quote selection. Apply the three-function test (Module 03) to every quote; cut ruthlessly.
- Next piece: endings. Does it land, turn, or complete an image? Rewrite until it does.
- Next piece: specificity. Replace every generic noun with a specific one. Count how many you find.

---

### 2. Poka-Yoke — Error-Proof the Workflow

**Design your writing process so errors are caught early, not discovered after filing.**

The journalism equivalent of type-system validation:

| Error type | When caught | Poka-yoke fix |
|-----------|------------|---------------|
| Structural failure | After full draft | Outline and angle-check BEFORE writing. Don't draft until the structure is sound. |
| Factual error | After publication | Verify every specific claim BEFORE finalising the draft, not as an afterthought |
| Quote accuracy | After dispute | Check quotes against notes or recording BEFORE filing |
| Missing nut graf | When editor queries | Read opening three paragraphs aloud — the nut graf must be audibly present |
| Wrong register | When editor rejects | Read target publication before every draft; calibrate vocabulary and sentence length |
| Anecdote without payoff | At revision | After every anecdote, ask: "What argument does this serve?" — before continuing |

**The fact-check gate:**
Every specific claim — name, date, figure, job title, quote — must be verified against source material before the piece leaves your hands. This is a gate, not an aspiration. A piece that fails the fact-check gate is not ready to file.

**The angle-lock:**
Before writing the first word of the draft, state the angle in one sentence. Pin it to the top of your document. Every section you write must serve that sentence. If a section doesn't serve it, either the section is wrong, or the angle is wrong — but one of them must change before you continue.

---

### 3. Standardised Work — Follow What Works; Document What Works

**Patterns that have worked should be studied, not abandoned.**

When a piece succeeds — when an editor commissions it on the first pitch, when a reader responds strongly, when it reads well on rereading — ask: what did I do that worked? Write it down. That is now your standard.

**Maintain a personal standards document:**
After each significant piece, note:
- What worked in the lead? (What type of lead, what specific technique)
- What worked in the structure?
- Which quotes were the most effective, and why?
- What did the editor change, and was the change an improvement? Why?
- What would you do differently?

Over time, this document becomes your personal craft guide — more specific and more useful than any generic writing advice because it is calibrated to your specific strengths and weaknesses.

**Standard tools that always apply (never skip):**
- The angle-lock statement before drafting
- The three-level revision (macro → mid → micro)
- The reading-aloud pass
- The final 10% cut review
- The fact-check gate before filing

These are not optional for "some pieces." They are the standard.

---

### 4. Just-In-Time — Build What the Piece Needs, Not What You Might Use

**The writing equivalent of YAGNI (You Aren't Gonna Need It):**

- Research until you have what you need, then stop. The temptation to keep researching is often the temptation to avoid writing.
- Report until you have the evidence for the angle, plus one layer of complication. Don't wait for the perfect source.
- Write to the length the piece needs. Not the length that shows how much you know.
- Include only the anecdotes, quotes, and examples that serve the central argument. However much you love a story, if it doesn't serve the piece, it doesn't belong in it.

**The "file for later" habit:**
Unused material — anecdotes that didn't make the cut, quotes that weren't quite right, research threads that led nowhere — should be filed, not discarded. Every unused anecdote is a potential lead for a future piece. Kaizen applies here too: the material that didn't serve this piece may be exactly what serves the next one.

---

## THE IMPROVEMENT LOOP

Apply this loop to every piece you write:

### Before writing
1. **Name one weakness from the last piece** that you will specifically address in this one
2. **State the angle** in one sentence and lock it at the top of the document
3. **Identify the article type** and load the relevant subskill
4. **Read the target publication** — three recent examples in the target slot

### During writing
5. **Write pass 1**: make it work — complete the draft without editing
6. **Angle-check**: does the draft serve the angle statement? If not, diagnose which is wrong — the structure or the angle
7. **Write pass 2**: make it clear — macro and mid revision
8. **Write pass 3**: make it strong — micro revision plus reading aloud

### After filing
9. **Assess the improvement**: did you address the weakness you named in step 1? What evidence?
10. **Note what worked and what didn't** in your personal standards document
11. **Name the next improvement target** — the specific weakness you'll address in the next piece

---

## MEASURING IMPROVEMENT

Kaizen without measurement is aspiration, not practice. Measurable improvements in magazine writing:

| Metric | How to measure |
|--------|---------------|
| Lead effectiveness | Did the editor change the lead? Did readers engage or disengage early? |
| Rejection rate | Track pitches to commissions ratio; improve angle-sharpness if high |
| Edit volume | How much did the editor change? Declining edit volume = improving craft |
| Fact-check errors | How many factual corrections were required at edit? Target: zero |
| Revision passes required | How many passes before the piece felt right? Target: decreasing over time |
| Time-to-strong-draft | How long from research to good draft? Track and improve efficiency |

The goal is not perfection. The goal is better than last time, in a specific, nameable way.

---

## THE KAIZEN MINDSET FOR REJECTIONS

Rejection is data. Apply Kaizen:

1. **Root cause analysis** (not self-blame): why was this rejected? Wrong angle for this market? Wrong register? Structural failure? Timing? No access?
2. **Identify one actionable fix**: not "I'm a bad writer" but "the lead didn't hook fast enough" or "the nut graf came too late"
3. **Apply the fix**: to this piece (if resubmitting) or to the next piece
4. **Track the pattern**: if the same problem appears across three rejected pieces, it is a skill gap — address it systematically

A pattern of rejections is not a verdict on talent. It is a signal of a specific, fixable weakness. Find it. Fix it incrementally. Repeat.

---

## THE CONTINUOUS IMPROVEMENT DECLARATION

Every writer using this skill should commit to these practices across all projects:

1. **Name the improvement target before every draft** — one specific, measurable thing to do better
2. **Iterate, don't perfect** — three passes, not one perfect pass
3. **Document what works** — maintain a personal standards record
4. **Error-proof the process** — the fact-check gate, the angle-lock, the reading-aloud pass are non-negotiable
5. **Treat rejection as data** — root-cause, fix, track, improve
6. **File the unused** — no material is wasted; archive for future use
7. **Never stop learning** — even R. L. Stevenson wondered if he'd ever learn to write

The writer who improves by 1% per piece, consistently, will be unrecognisable in a year. That is Kaizen.

---

## PERSONAL STANDARDS DOCUMENT — TEMPLATE

Copy and maintain this document. Fill in after every significant piece filed.

```
PIECE: [Title / Publication / Date filed]
TYPE: [Profile / How-to / Investigative / Column / etc.]

IMPROVEMENT TARGET (set before writing):
  What specific weakness from the last piece were you addressing?
  _______________________________________________

RESULT:
  Did you achieve it? Evidence:
  _______________________________________________

WHAT WORKED:
  Lead type used and why it worked:
  _______________________________________________
  
  Structure decision that served the piece:
  _______________________________________________
  
  Most effective quote and why (apply three-function test):
  _______________________________________________

WHAT THE EDITOR CHANGED:
  Specific changes and whether they were improvements:
  _______________________________________________
  
  What does the pattern of edits reveal about your current weakness?
  _______________________________________________

FACTS VERIFIED / ERRORS FOUND:
  Number of factual corrections required at edit: ___
  Target: zero. If non-zero: root cause?
  _______________________________________________

NEXT IMPROVEMENT TARGET:
  One specific, measurable thing to do better in the next piece:
  _______________________________________________
```

---

## KAIZEN FOR THE PITCH, NOT JUST THE PIECE

The improvement loop applies to pitching too.

**Track:**
- Pitches sent vs commissions received (your strike rate)
- Rejection patterns: is the same publication rejecting you repeatedly? Same type of piece?
- Time from pitch to response: are you following up appropriately?

**Root-cause analysis on rejections:**
- Wrong market for this angle? → Improve market research before pitching
- Angle not sharp enough? → Apply Module 01 more rigorously before sending
- Pitch prose not compelling? → The query letter is a writing sample; apply Module 03 to it
- No news peg or timeliness? → Develop the "why now" before pitching, not after
- No prior relationship with this editor? → Consider starting with smaller publications to build track record

**The strike rate target:**
A professional freelancer working at their level should commission roughly 1 in 5–7 pitches to new editors, improving over time. If the rate is lower, identify the most common failure point and address it systematically.

---

## THE COMPOUND EFFECT

Small, specific improvements compounded over time produce transformative results.

| Improvement per piece | After 10 pieces | After 50 pieces |
|----------------------|-----------------|-----------------|
| 1% better at leads | 10% stronger openings | 50% stronger openings |
| 1% better at transitions | Near-invisible transitions | Effortless flow |
| 1 fewer cliché per draft | Cliché-free openings | Cliché-free throughout |
| 1 stronger verb per paragraph | Noticeably more energetic prose | Distinctive voice through verb strength |

The compound effect in writing is not metaphorical. It is measurable in reduced editor interventions, stronger commissions, and reader response. The writer who improves 1% per piece will be unrecognisable in a year.

**That is Kaizen. That is the practice.**

---

## KAIZEN AND THE WRITER'S INNER LIFE

The improvement loop applies to craft metrics — leads, transitions, quote selection. But Kaizen's self-improvement dimension also addresses the psychological patterns that limit development. Name the pattern. Apply the fix. Track the result.

### The five inner patterns that block improvement

**1. Perfectionism masquerading as standards**
Symptom: drafts are never good enough to show; pieces are endlessly revised and never filed; the blank page produces paralysis.
Kaizen response: standards are about the filed piece, not the first draft. The first draft's job is to exist. Set a timer: 45 minutes, write without stopping, produce a bad draft. The revision is where standards apply.

**2. Comparison that doesn't compare like with like**
Symptom: reading a writer whose work you admire and concluding that your own work is inadequate.
Kaizen response: compare your work to your previous work, not to the best work of others. Are you improving? By how much? That is the relevant measure.

**3. Catastrophising rejection**
Symptom: one rejection triggers a reassessment of whether writing is worth pursuing.
Kaizen response: rejection is data about one editor's view of one piece for one publication on one day. File it. Do the root-cause analysis. Pitch the next thing.

**4. Achievement without consolidation**
Symptom: a strong commission or publication triggers elation followed by immediate anxiety about the next thing; the achievement doesn't register as progress.
Kaizen response: use the standards document. Record what worked. Acknowledge the achievement as evidence of a pattern, not a fluke. Then identify the next improvement target.

**5. Confusing busyness with productivity**
Symptom: long hours at the desk with little actual output; research that never becomes a draft; pitches that are almost ready.
Kaizen response: measure output, not time. What was produced this week? What moved forward? Time at the desk is an input. Published words and filed pitches are outputs. Track outputs.

### The Kaizen commitment to self

The same rigour that applies to improving the lead applies to improving the writer. Once per month, apply these questions:

- What is the one craft element that most limits my work right now?
- What would I need to do differently to improve it?
- What is the smallest possible action that moves me toward that improvement?

The answers should be specific and actionable. "Improve my writing" is not an answer. "Write one anecdote lead per week for the next month, compare them, and identify what makes the strongest one work" is an answer.

Kaizen in the craft, Kaizen in the self. That is the full practice.

---

## → Where this module leads

**The improvement loop feeds directly into:**
Load `subskills/revision-and-self-editing/revision-and-self-editing.md` — the three-level revision workflow is where the improvement targets you set here are actually applied to a piece.

**For writer development beyond individual pieces:**
Load `references/09_writer_development.md` — specialisation building, editor relationships, and the career-level Kaizen loop extend this module's principles into the long game.

**For the pitch improvement loop:**
Load `references/04_pitch_and_query.md` — the pitch log and strike-rate tracking system described in Module 06 connects to the practical pitch mechanics in Module 04.

**When the improvement feels blocked by psychological patterns:**
This module's "inner life" section and Module 09's writer resilience section overlap deliberately — read both if a writer is stuck not on craft but on practice.
