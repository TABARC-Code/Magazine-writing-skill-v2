# Module 05 — Publication Standards

Every publication has an editorial DNA. Writing well is not enough. Writing well for this publication is the standard.

---

## What publication DNA means

Publication DNA is the combination of:

- **Reader assumption**: who the editor imagines reading the piece (education level, disposable income, political outlook, what they do at weekends)
- **Editorial voice**: the house tone — ironic, earnest, campaigning, detached, authoritative, intimate
- **Subject territory**: what subjects this publication considers its own
- **Structural preferences**: long-form vs short-form, narrative vs analytical, service vs opinion
- **Political and cultural alignment**: where the publication sits in the landscape and how openly it signals this

You identify these by reading six to eight recent issues — not skimming, reading — and noting patterns. What is the dominant sentence length? How many sources appear in a typical feature? Does the magazine quote experts more than eyewitnesses? Does it run first-person? Does it use subheads or let long prose run unbroken?

---

## Publication type calibration

### Broadsheet weekend supplement
*Examples: FT Weekend Magazine, Guardian Weekend, Observer Magazine, Telegraph Magazine*

- **Length**: 2,000–5,000 words for features; 800–1,200 for columns
- **Tone**: serious but not dry; occasionally ironic; assumes educated, engaged reader
- **Structure**: narrative features with strong reporting; opinion must be argued, not asserted
- **Voice**: individual writer voice valued; publication voice is less homogeneous than tabloid supplements
- **What editors want**: access journalism, counterintuitive ideas, strong characters, evidence-led analysis
- **What to avoid**: worthy but dull, underpowered leads, features that could have been written without any reporting

---

### Mid-market consumer magazine
*Examples: GQ, Stylist, Vogue, Esquire, Elle, Red*

- **Length**: 800–2,500 words
- **Tone**: confident, direct, slightly aspirational; commercial context is visible
- **Structure**: service orientation common even in features; readers want to take something away
- **Voice**: publication voice is strong; individual writer voice fits inside it
- **What editors want**: timely, culturally relevant, well-sourced, visually imageable
- **What to avoid**: academic density, political complexity without strong hook, lack of practical angle

---

### Sunday newspaper magazine supplement
*Examples: Sunday Times Magazine, Sunday Telegraph Magazine, The Times Magazine*

- **Length**: 2,000–4,000 words for features
- **Tone**: accessibly serious; family readership assumption; strong news peg usually required
- **Structure**: narrative features with scene-led opening; clear nut graf early
- **Voice**: professional, competent, measured; wit permitted if earned
- **What editors want**: human interest with broader relevance; good access; recognisable names or subjects
- **What to avoid**: niche subjects without mass hook; first-person without sufficient external reporting; political pieces without news justification

---

### Trade and professional press
*Examples: Marketing Week, The Grocer, Architects' Journal, Nursing Times*

- **Length**: 600–2,000 words
- **Tone**: professional, peer-to-peer; assumes technical fluency
- **Structure**: news peg essential; analysis over narrative
- **Voice**: neutral; institutional; individual voice is minimal
- **What editors want**: relevant sector news, expert voices, data, practical implications
- **What to avoid**: consumer-magazine narrative style; explaining basics to specialists; jargon from adjacent fields

---

### Literary and cultural magazine
*Examples: Granta, London Review of Books, The Economist (culture section), New Statesman*

- **Length**: 2,000–6,000 words; LRB can run much longer
- **Tone**: essayistic; highly literate reader assumed; argument expected to be complex
- **Structure**: less rigid; essayistic structure common; may not have explicit subheads
- **Voice**: individual voice central; publication cultivates distinct contributors
- **What editors want**: genuine intellectual provocation; original ideas; deep research; elegant prose
- **What to avoid**: conventional feature structure; superficial argument; writing that could appear elsewhere

---

### Specialist interest magazine
*Examples: Wired, New Scientist, History Today, World of Interiors, Decanter*

- **Length**: 1,000–3,000 words
- **Tone**: enthusiastic, knowledgeable, curious; assumes passionate reader
- **Structure**: driven by the subject; more flexible than consumer press
- **Voice**: writer's enthusiasm can show; expertise is credibility
- **What editors want**: new developments in the field, expert access, genuinely fresh angles on the specialism
- **What to avoid**: patronising the reader's existing knowledge; surface-level treatment; angles that have been done repeatedly

---

## Reading a publication for calibration

Before writing a piece for any publication, carry out this exercise:

1. **Read three recent features in the target slot** (not the whole magazine — the slot where your piece would land).
2. **Count**: average sentence length, number of sources quoted, number of scenes vs straight reportage passages, presence or absence of the writer's voice.
3. **Note**: where the nut graf appears, what kinds of leads are used, how pieces end.
4. **Identify**: the one thing that makes this publication's features feel different from competitors.
5. **Write your piece to that standard**, not to a generic magazine standard.

---

## House style basics

Every publication has a style guide. Writers rarely see it until they're on staff, but most house style decisions follow predictable patterns:

- **Date format**: varies (4 March vs March 4 vs 4th March)
- **Quotation marks**: single vs double (UK publications typically single; US typically double)
- **Spelling**: UK English vs US English (know which and stick to it)
- **Numbers**: words vs numerals threshold varies — usually spell out under ten or under twenty
- **Job titles**: capitalised before name in some publications; lowercase in others
- **Named organisations**: the Guardian uses lowercase "the"; the BBC uses uppercase "The" — these are deliberate choices

When in doubt, default to whatever the publication uses in its own text. Editors correct for house style — they do not expect external writers to know every rule — but flagrant inconsistency signals a careless writer.

---

## What "high-spec output" means in practice

When this skill targets a high-spec publication (broadsheet supplement, literary magazine, or quality consumer press), the following quality checks apply to every output:

1. **No cliché in the first three paragraphs.** If the opening contains "in a world where..." or "now more than ever," rewrite it.
2. **Every quote must earn its place.** Apply the three-function test (Module 03).
3. **The nut graf must be explicit and early.** A reader should be able to identify it.
4. **No sentence over 45 words** unless the complexity is doing genuine work.
5. **No adjective stacking.** One precise adjective beats three vague ones.
6. **The ending does not summarise.** It lands, turns, or completes an image.
7. **Every claim is attributed or established.** No floating assertions.
8. **The whole piece sounds like one writer wrote it.** Tonal consistency throughout.

---

## → Where this module leads

**Once the publication is calibrated, apply the register to prose:**
Load `references/03_prose_and_voice.md` — sentence length, vocabulary range, and tone are all calibrated here against the publication standard you've just established.

**If the angle needs adjusting for this publication:**
Load `references/01_subject_and_angle.md` — a great angle for one publication may need reframing for another. The publication's DNA shapes what version of the angle to pitch.

**For rates, rights, and what to expect from this type of publication's contracts:**
Load `references/07_freelance_business.md` — publication type (broadsheet, trade, literary, consumer) strongly predicts the contract terms you'll encounter.

**For short fiction market calibration specifically:**
Load `subskills/short-fiction/short-fiction.md` — consumer magazine fiction has its own market-reading process distinct from feature calibration.
