# Module 03 — Prose and Voice
*Source-validated from: Hennessy (Writing Feature Articles), Ruberg (Writer's Digest Handbook), Fink (Writing to Inform and Engage)*

Structure gets the reader in. Prose keeps them there. This module covers sentence-level craft for magazine and newspaper feature writing.

---

## Register: knowing what level you're writing at

Register is the combination of vocabulary, sentence length, formality, and tone that defines how a piece sounds. Magazine writing is not one register — it is a spectrum.

| Publication type | Avg sentence length | Vocabulary | Tone |
|-----------------|-------------------|------------|------|
| Broadsheet supplement (FT Weekend, Guardian Weekend) | 20–30 words | Precise, elevated | Serious, analytical, occasionally ironic |
| Mid-market consumer (Stylist, GQ, Vogue) | 15–25 words | Accessible, sharp | Confident, direct, sometimes playful |
| Sunday newspaper column | 12–20 words | Plain, emphatic | Personal, opinionated, urgent |
| Trade press | 20–35 words | Specialist terminology expected | Neutral, evidence-led |
| Literary magazine (Granta, LRB) | 25–40 words | Complex, layered | Reflective, essayistic |
| Specialist interest (Wired, New Scientist) | 18–28 words | Technical but explained | Curious, engaged, slightly informal |
| Popular consumer (tabloid supplements) | 8–15 words | Plain, punchy | Immediate, sensational in the best sense |

Read the target publication and count sentences. Match the rhythm before writing.

---

## Sentence craft

### Vary length deliberately

Long sentences build atmosphere, context, and complexity. Short sentences land emphasis.

Use a short sentence after a long one when you want the reader to stop and feel the weight of something. Alone. Just like that.

Magazine writers who write in uniform sentence lengths — either always long or always short — create prose that feels either airless or breathless. Vary with intention.

The tabloid technique applied to quality writing: three typewritten lines for a sentence is the absolute maximum. Beyond that, the reader's eye slips.

### The active voice

In most magazine contexts, active voice is default. Passive voice obscures agency.

- **Passive**: "The report was suppressed."
- **Active**: "The department suppressed the report." — and now you must name who did it, which is often the point.

Passive voice is acceptable when the agent is genuinely unknown or unimportant, or when you're deliberately withholding information for effect. Use it consciously, not by default.

### Verbs are the engine

Replace weak verb + noun constructions with strong single verbs:

| Weak | Strong |
|------|--------|
| made a decision | decided |
| gave consideration to | considered |
| had a meeting | met |
| is a demonstration of | demonstrates |
| carried out an investigation | investigated |
| put a damper on | dampened |

Magazine prose moves because the verbs are doing work. If your verbs are "be," "have," "make," "do," and "give" in every sentence, the prose is stalling.

Use active verbs especially in anecdotes and scene-setting. Compare:

- **Weak**: "There was a confrontation between Bolivar and the crowd."
- **Strong**: "Bolivar walked off the court in disgust."

### Specificity in nouns

Generic nouns blunt the picture. Specific nouns sharpen it.

- "a car" → "a 2019 Volvo XC60"
- "a building" → "a Victorian warehouse conversion"
- "food" → "a plate of cold börek, wrapped in foil from the market"

This is not pedantry — it is the difference between a piece that stays abstract and one that puts the reader somewhere real. The best magazine writers see in specifics. Your prose should too.

---

## Vary pace and rhythm

However interesting your content, monotonous rhythm loses readers. Variations should become instinctive.

Two structuring techniques:

1. **Vary pace across sections**: A brisk intro may be compelling. The body may need to slow down for description, explanation, or argument. Then speed up again for the home stretch.

2. **Vary within paragraphs**: Reverse the normal word order occasionally. Put the subject at the end for emphasis. A passive can be deliberate punctuation. Short sentences after long ones signal arrival.

Here is a paragraph with deliberate variations, from Hennessy's *Writing Feature Articles*, illustrating how rhythm carries irony without stating it:

> "Our curriculum is small and carefully designed. Physics lessons stop well short of chaos theory (far too upsetting a concept for our sensitive undergraduates)."

The formal construction amplifies the joke. The parenthetical is the blade. This is rhythm in service of tone.

---

## Transitions

Transitions are the connective tissue between sentences, paragraphs, and sections. In magazine writing, they must be invisible.

### Sentence-to-sentence transitions

Use: pronouns, repeated key words (repetition creates link — don't replace with synonyms), logical connectors.

**Avoid**: "However," "Furthermore," "In addition," "Moreover" at the start of every paragraph. These are academic connectors, not magazine ones. Use them sparingly.

### Section-to-section transitions

A good transition out of a section anticipates the next topic without stating it bluntly.

- **Weak**: "Now let us turn to the question of cost."
- **Better**: "The political will exists, at least in theory. The money is another matter."

Strong transition technique: use a key word from the ending of the previous section as the first or second word of the next. The reader's eye follows the thread without noticing it.

### The linking quote

Quotes can serve as transitions. A source's statement that opens the next angle of the argument is both content and structure simultaneously.

---

## Handling quotes

Quotes in magazine articles serve three purposes:

1. **Voice**: the source says something in a way only they would say it
2. **Authority**: the source's expertise or position lends weight to a claim
3. **Drama**: the source says something that moves the piece forward emotionally or narratively

If a quote does none of these three things, paraphrase it.

### Quote rules

- Never start an article with a quote.
- Vary the attribution verb when needed: said, told, explained, recalled, argued, admitted — but "said" is always acceptable and often best.
- Trim quotes. Cut everything that is not the irreplaceable part.
- Don't stack quotes. Two sources quoting in sequence without narrative or analysis between them is lazy.
- Don't use partial quotes to avoid taking responsibility: "She said the situation was 'very concerning.'" — if it's just two words, paraphrase it.
- Sanctity of direct quotation is absolute. Words in quotation marks were actually spoken. Never invent, never composite, never lift from secondary sources and attribute as if live.
- Grammar in quotes: minor corrections (wrong tense, pronoun agreement) are acceptable if they don't change meaning. Meaning-changing edits require indirect quotation.

---

## Scene-setting

Magazine features use scenes — short passages of narrative description that put the reader somewhere. Scenes are not decoration. They are argument by another means.

A scene should:
- Be grounded in specific sensory detail (at least two senses)
- Contain a moment of tension, decision, or revelation
- Connect to the piece's central idea — doing argumentative work, not just adding colour

**Scene construction order**: situation → detail → meaning. Not the reverse.

**Length**: A scene in a magazine article is usually 100–300 words. Longer and it becomes self-indulgent unless the piece is explicitly narrative or literary.

### The "sensory data" principle

The best magazine writing relies on sensory data — descriptive passages that appeal to the five senses or convey motion. This is why face-to-face interviews are often more productive than phone interviews: you can observe, not just listen.

When setting scenes: what can you see, hear, smell, feel? Choose the two details that do the most work and cut the rest.

---

## The tabloid toolkit (applicable to all registers)

The tabloid techniques below were developed by mass-market publications that live or die by reader engagement. They apply — in appropriately calibrated form — to every type of magazine writing:

1. **Never be boring.** Boring is the cardinal sin. Find the element that makes the reader say "I have to tell someone this."

2. **Find the "Hey Martha."** The amazing amount, the incredible feat, the counterintuitive fact — the thing that makes the reader turn to someone else and say, "Get a load of this." It's not just that Huneck built a church for dogs; it's that he spent $200,000 to do it.

3. **Use your best shot first.** Don't save the most fascinating aspect as a payoff. Most readers will not wait. The most shocking or surprising element belongs near the front.

4. **Make a long story short.** Take ten pages of notes and distil them into the one page of copy packed with fascinating details, illuminating background, and hard-hitting action.

5. **Use effective transitions.** "Glick and the other heroes stormed from their seats and into history." When you write tightly, transitions between aspects of a story are crucial.

6. **Pace yourself.** Vary story with longer and shorter sentences. Three typewritten lines is the maximum sentence length. This creates the breathless feel of an exciting read.

7. **Keep it simple.** Write to express first, impress second. The reader shouldn't have to work to understand.

8. **Use active verbs.** "Cops busted Robert Downey Jr. for drugs" is more exciting than "Robert Downey Jr. was taken into custody by police for possession of an illegal substance."

9. **Give it a top and tail.** The story should be almost circular, returning to the lead at the end. Don't let it trail off.

---

## Tone control

Tone in a long piece is easy to lose. It drifts toward the writer's natural voice rather than the publication's expected voice.

Techniques for maintaining tone:
- Before drafting each section, reread the last paragraph of the previous one.
- Read the opening and the current section back-to-back. Do they sound like the same writer?
- If the piece shifts between earnest and ironic, make those shifts intentional and structural — don't let them happen by accident.

### On irony and humour

Irony is a high-risk tool in journalism. It works brilliantly in the hands of a skilled practitioner and catastrophically otherwise. Test: read the ironic passage aloud. If it sounds like you're winking at the camera, it's probably too much.

### Avoiding egotism and pomposity

Write as you speak — but not exactly. You wouldn't want the "ers" and "ums," but the injunction warns against egotism, pomposity, preachiness, and ostentation. Avoid:

- Prefacing with "It's important to keep in mind that..." (pompous impersonal statement)
- "It's not generally realised that..." (positions the writer as superior)
- "While the British public remains indifferent to..." (preaching; include yourself in the complaint)

Keep the first person to the minimum unless the piece is explicitly first-person. How the army of personal columnists sustains interest is a subject for another chapter — and even they must earn every "I."

### Euphemism and "fuzz"

**Euphemisms** can be harmless, but sinister euphemisms — "moderate physical pressure," "collateral counterforce damage" — should be named for what they are. Don't let official language do your thinking for you.

**"Fuzz"** is when you imply linkage between facts and events when there is none, or at best a tenuous one. Stating a chronological relationship and implying a causal one without stating it is a common failure in political and trend writing. Name it when you're doing it; or don't do it.

---

## Voice vs style

**Voice** is the quality that makes one writer's work distinct from another's — the way they see, the things they notice, the rhythm of their sentences, the risks they take.

**Style** is the set of technical choices that express that voice: sentence length patterns, punctuation habits, vocabulary range, structural preferences.

In magazine writing for hire, style has to adapt. Voice does not have to disappear — the best magazine writers sound like themselves inside the publication's constraints. The way to do this is not to imitate the publication's surface features, but to understand what the publication values and deliver that through your own lens.

---

## Write as you speak (carefully)

The injunction "write as you speak" means: write as naturally as possible. Avoid:

- Egotism (assuming every thought interests the reader)
- Pomposity (formal constructions that exist to impress)
- Preachiness (moralising at the reader)
- Ostentation (using complexity to signal intelligence)

The best prose reads as though it were effortless. It is not effortless. It is the result of many drafts removing every word that was there to serve the writer rather than the reader.

---

## Common prose failures in feature writing

| Failure | Example | Fix |
|--------|---------|-----|
| Throat-clearing opening | "In recent years, it has become increasingly apparent..." | Start in the middle of something |
| Adjective overload | "The stunning, vibrant, unmistakably unique..." | Pick one adjective; make it precise |
| Cliché scaffolding | "At the end of the day," "game changer," "perfect storm" | Write around the cliché; find the image underneath it |
| Nominalisation creep | "The implementation of the regularisation of..." | Use verbs: "regularise," "implement" |
| Overuse of "very" | "very important," "very significant" | Cut "very." If the word needs intensifying, find a stronger word |
| Unnecessary attribution | "According to research, water is wet." | Remove attribution for established facts |
| Scare quotes | "The so-called 'experts'" | Either attribute properly or remove the distancing quotation marks |
| Unearned emotional language | "tragically," "shockingly," "devastatingly" | Let the facts carry the weight; don't instruct the reader how to feel |
| Fuzz causation | "After the scandal, the policy changed..." (implying link) | State what is known; distinguish correlation from cause |
| Four-syllable words by default | "utilisation," "commencement," "amelioration" | Ask if a shorter word carries the same meaning; make it a conscious choice |
| Sexist pronouns (old fix) | "he" as default | Use plural, alternate, or recast the sentence — not "she" as reversal |
| PC language that obscures | "visitor flow management" for crowd control | Name the thing; don't let euphemism do ideological work on the reader |

---

## The four style modes

Every article mixes four modes of writing. Knowing which mode you're in — and whether it's the right one for this moment — is a mark of craft maturity.

### 1. Description
Creates a picture. Puts the reader somewhere. Slows pace. Works in scene-setting, profile openings, travel writing, and narrative features.

Requirements:
- Specific, sensory detail — at least two senses
- Movement (something is happening, even if slowly)
- No "fuzz" — describe what you observed, not what you inferred

Failure mode: static description — cataloguing what things look like without action or meaning.

### 2. Narration
Tells what happened, in sequence. The engine of profiles, investigations, personal experience, and narrative features. Creates momentum.

Requirements:
- Clear time sequence
- Agents who act (someone does something to something or someone)
- Tension — something is at stake
- Scenes and summary alternating; scenes at moments of drama, summary to cover ground

Failure mode: chronological from the beginning (the "once upon a time" error) — start at the crisis, backfill.

### 3. Exposition
Explains. Informs. Provides context the reader needs to understand the argument. The mode of background sections, how-tos, and analytical features.

Requirements:
- Clarity above elegance — if elegance helps, use it; if it complicates, don't
- Build from what the reader knows to what they don't
- One idea at a time; don't stack explanations

Failure mode: over-explanation — treating the reader as less intelligent than they are; over-hedged claims that never commit; sentences that need three readings.

### 4. Argument
Makes a claim and supports it. The mode of opinion columns, analysis pieces, and investigative conclusions.

Requirements:
- The claim must be stated clearly and early
- Evidence must be proportionate to the claim's strength
- Counterarguments must be acknowledged and addressed
- Conclusion must be stronger than the opening claim, having earned the upgrade

Failure mode: the "fuzz" argument — events presented as causally linked without evidence; chronological relationship implied as causation.

### Mixing modes in practice

A 2,000-word feature typically moves through all four modes. A rough map:
- Lead: description or narration (puts the reader in a scene)
- Nut graf: brief exposition (here is the context)
- Body sections: alternating narration/description (the human story), exposition (the background and data), argument (what it means)
- Ending: narration or description (closes the scene) + implicit argument (the final claim)

Recognise which mode each paragraph is in. If a section is trying to do all four at once, it will do none well.

---

## Writing for digital/online publication

Online readers browse more than they read. The writing values are identical to print — accuracy, authority, voice, specificity — but the structural adaptations matter.

### Key differences from print

- **Readers scan before they commit**: the first screen of text must earn the scroll. If it doesn't, the reader leaves.
- **Length on screen**: a 4,000-word piece from a newspaper cannot be placed unchanged on a web page. Rethink the structure; break into navigable sections; consider whether some material becomes a sidebar, a linked piece, or a sub-page.
- **Interactivity is available**: surveys, user polls, multimedia, linked resources — ask whether any of these make the piece a better online experience.
- **Half the text**: as a rough rule, online content should be approximately half the word count of a print equivalent. Cut the most ruthlessly; keep only the essential.

### What doesn't change

- Accuracy and authority are non-negotiable regardless of medium
- The lead must still hook within the first paragraph
- Voice and specificity matter as much online as in print
- The reader still needs to know why they're reading (the nut graf equivalent applies)

### Writing effectively for online

- Use subheads more liberally — they serve as navigation for scanning readers
- Shorter paragraphs (two to three sentences maximum as a norm)
- Break complex material across multiple interlinked pages rather than one long scroll
- Each section should be capable of standing alone — readers may arrive mid-piece
- Read the online publication as a user: participate, understand the audience, then pitch

---

## Headlines and titles: the craft dimension

The headline is the most-read part of any piece. It does four jobs simultaneously: promises the content, signals the register, earns the click or page-turn, and — in digital contexts — functions as a search term.

### Print headline craft

A strong print headline:
- Is specific, not generic ("Why your GP can't see you" beats "The NHS crisis")
- Makes a promise the piece keeps
- Uses active voice wherever possible
- Does not summarise — it entices
- Matches the register of the publication

**The headline test**: Cover the article. Read only the headline. Does the reader know approximately what the piece is and why it might be worth their time? If not, rewrite.

**Headline types**:
- **Declarative**: states the piece's central claim ("Britain's nuclear workforce is ageing out")
- **Question**: asks what the piece answers ("Who decides when a building is beautiful?")
- **Command/imperative**: used sparingly in service journalism ("Stop treating your sourdough like a houseplant")
- **Witty/pun**: appropriate for lighter registers only; must work on both levels or not at all
- **Label**: identifies the subject without spin ("A life in music: Shirley Collins")

**Subheadings (decks/standfirsts)**:
Usually 20–40 words. Expand on the headline without repeating it. Give the reader enough to decide whether to read. Often written by editors but the writer should draft one — it clarifies the piece's promise and helps the editor.

### Digital headline craft: the SEO dimension

Online, the headline also functions as a search query match. Readers who arrive via search engines typed something — and your headline should connect to what they typed.

This does not mean ugly keyword-stuffed headlines. It means:
- **Front-load the key term**: place the primary subject early in the headline ("Electric vehicle charging: why rural drivers are being left behind")
- **Be specific about what the piece delivers**: readers and search algorithms both reward specificity
- **Use plain language for searchable terms**: the literary pun headline may perform worse in search than a direct statement

**The dual-headline approach** (used by major online publications):
- **Print-style headline**: witty, registrally appropriate, designed for readers already on the page
- **SEO/social headline**: direct, keyword-rich, designed for search and sharing

Some publications display both; others use one for the URL and one for on-page display. As a writer contributing digitally, ask the editor which is required.

**Headline length for digital**:
- 50–60 characters: optimal for search results display without truncation
- Under 80 characters: workable
- Over 100 characters: will be cut in search results; lead with the most important information

**What doesn't change in digital headlines**:
- The promise must still be kept by the piece
- Clickbait headlines ("You won't believe what happened next") damage reader trust and are penalised by most algorithms
- Accuracy: a misleading headline is an editorial failure, not just an SEO problem

---

## SEO essentials for digital magazine writing

For writers producing content primarily for digital publication. Print-first writers can skim; digital-first writers should apply these consistently.

### Search intent

Every search query has an intent behind it. Match your piece to the intent:
- **Informational**: the reader wants to learn ("how does X work" — write an explainer)
- **Navigational**: the reader wants to find something specific (less relevant to magazine writing)
- **Transactional**: the reader wants to do or buy something (relevant to service journalism)

The mismatch failure: writing a personal essay in response to an informational query. The piece may be beautifully written; it won't rank, and it won't satisfy the reader who arrived looking for an explanation.

### Keyword integration

**Natural integration, not stuffing**:
Use the primary subject term where it naturally belongs — in the headline, the first paragraph, one or two subheadings, and naturally within the body. Do not force repetition that harms readability.

**The reader-first test**:
Read the piece without thinking about keywords. Does it read naturally? If a sentence only exists because it contains a keyword, remove or rewrite it.

### Meta description

A 140–155 character summary of the piece for search engine results pages. The writer often doesn't control this (editors or CMSs generate it), but when you do:
- Summarise the piece's core value in plain language
- Include the primary keyword naturally
- End with an implicit or explicit hook that earns the click

### Structural signals for search

Subheadings (H2, H3 in HTML) help search engines understand structure. For digital pieces:
- Use subheadings every 300–500 words
- Make subheadings descriptive, not clever — they are navigation as much as prose
- The H1 is your headline; H2s are your section headings

### AI and search in 2025–26

Google's AI Overviews increasingly summarise content in search results, reducing direct traffic to articles. This creates a tension: optimise for AI summarisation (be direct, informative, quotable) or optimise for clicks (be enticing, create curiosity gaps).

The writer's response: write with sufficient clarity and authority that your piece is the source AI tools quote. Original reporting, expert access, and specific data points are what AI summaries draw from — and what earns citation rather than replacement.

---

## → Where this module leads

**For revising an existing draft using these prose principles:**
Load `subskills/revision-and-self-editing/revision-and-self-editing.md` — the three-level revision workflow applies Module 03 systematically to a drafted piece.

**For leads and endings specifically:**
Load `subskills/leads-and-endings/leads-and-endings.md` — the two highest-stakes prose moments in any piece have their own dedicated guidance.

**For register calibration against a specific publication:**
Load `references/05_publication_standards.md` — publication DNA and the calibration checklist.

**For tracking prose improvements across pieces:**
Load `references/06_kaizen_improvement.md` — the improvement loop applies prose-level targets (leads, transitions, verb strength) systematically over time.
